import { createRouter, createWebHistory } from 'vue-router'
import Home from '../components/Perfil/Home.vue'
import Login from '@/components/Login/Login.vue'
import Register from '@/components/Login/Register.vue'
import Recaudacion from '@/components/Recaudacion/DetalleRecaudacion.vue'
import NuevaRecaudacion from '@/components/Recaudacion/NuevaRecaudacion.vue'
import Inicio from '@/components/Compartidos/Inicio.vue'
import EditarPerfil from '@/components/Perfil/EditarPerfil.vue'
import EditarRecaudacion from "@/components/Recaudacion/EditarRecaudacion.vue";
import HomeAdmin from "@/components/Administrador/HomeAdmin.vue";
import RecaudacionAdmin from "@/components/Administrador/InfoRecaudacionAdmin.vue";
import Motivo from "@/components/Administrador/MotivoRecaudacion.vue";
import PagoRealizado from "@/components/Recaudacion/PagoCorrecto.vue";
import PagoErroneo from "@/components/Recaudacion/PagoErroneo.vue";
import Valoracion from "@/components/Valoraciones/Valoracion.vue";
import ValoracionAdmin from "@/components/Administrador/InfoValoracionAdmin.vue";
import Error404 from "@/components/Login/404.vue";
import NetworkError from "@/components/Login/NetworkError.vue";
import RecuperarContrasena from "@/components/Perfil/RecuperarContrasena.vue";

const router = createRouter
({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: Inicio,
    },
    {
      path: '/inicio',
      component: Inicio,
    },
    {
      path: '/home',
      component: Home,
    },
    {
      path: '/login',
      component: Login
    },
    {
      path: '/register',
      component: Register
    },
    {
      path: '/recaudacion/:id',
	  name: 'recaudacion',
      component: Recaudacion,
	  props: true
	},
	{
	  path: '/recaudacion',
	  component: Recaudacion,
	},
    {
      path: '/crearRecaudacion',
      component: NuevaRecaudacion
    },
    {
      path: '/editarPerfil',
      component: EditarPerfil
    },
	{
	  path: '/editarRecaudacion/:id',
		name: 'editarRecaudacion',
	  component: EditarRecaudacion,
		props: true
	},
	// RUTAS DEL ADMIN
	{
		path: '/homeAdmin',
		component: HomeAdmin,
	},
	{
		path: '/recaudacionAdmin/:id',
		name: 'recaudacionAdmin',
		component: RecaudacionAdmin,
		props: true
	},
	{
		path: '/motivo/:id',
		name: 'motivo',
		component: Motivo,
		props: true
	},
	{
		path: '/pagoRealizado',
		component: PagoRealizado,
	},
	{
		path: '/pagoErroneo',
		component: PagoErroneo,
	},
	{
		  path: '/valoranos',
		  component: Valoracion,
	},
	{
		path: '/valoracionAdmin/:id',
		name: 'valoracionAdmin',
		component: ValoracionAdmin,
		props: true
	},
	{
		path: '/404',
		component: Error404,
	},
	{
		  path: '/NetworkError',
		  component: NetworkError,
	},
	{
		  path: '/RecuperarContrasena',
		  component: RecuperarContrasena,
	},
  ],
})

export default router

