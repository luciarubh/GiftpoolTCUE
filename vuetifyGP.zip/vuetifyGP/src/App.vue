<script setup>
import Nav from '@/components/Compartidos/Nav.vue'
import {defineComponent, onMounted, ref} from "vue";
import { useStore } from 'vuex'
import {useRouter} from "vue-router";

const store = useStore()
const router = useRouter()
var usuarioLogeado = ref(null)

store.dispatch('setUsuarioLogeado', usuarioLogeado)     //Hacer que la variable usuario sea visible y modificable por todos

defineComponent({
  components: {Nav}
})

onMounted(async () => {
	try {
		const response = await fetch("http://localhost:8000/api/check", {
			headers: {"Content-Type": "application/json"}
		})
	}catch (e) {console.log("Error en conexion"); router.push('/NetworkError');}
})

</script>

<template>
  <v-app style="min-width: 300px; min-height: 400px;">
    <Nav style="position: static; margin-bottom: 0px;"/>
    <v-main style="position: static; --v-layout-top: 0px; ">
		<div style="margin-top: 0px; padding-top: 0px; --v-layout-top: 0px; width: 100%; height: 100%;">
      		<router-view />
		</div>
    </v-main>
  </v-app>
</template>

<style>
  html {
    overflow-y: auto /*Quitar scrollbar*/
  }
</style>


