import { createStore } from "vuex"

export default createStore({
  state: {
    authenticated: false,
    usuarioLogeado: null,
  },
  mutations: {
    SET_AUTH: (state, auth) => (state.authenticated = auth),
    SET_USUARIO_LOGEADO: (state, usuario) => (state.usuarioLogeado = usuario),
  },
  actions: {
    setAuth: ({ commit }, auth) => commit("SET_AUTH", auth),
    setUsuarioLogeado: ({ commit }, usuario) => commit("SET_USUARIO_LOGEADO", usuario)
  },
  modules: {}
})
