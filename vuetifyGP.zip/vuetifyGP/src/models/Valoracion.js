export default class Valoracion {
	constructor(rating, positivo, negativo, userId, username, fecha) {
		this.rating = rating;
		this.positivo = positivo;
		this.negativo = negativo;
		this.username = username;
		this.userId = userId;
		this.fecha = fecha;
	}
}
