export default class User {
  constructor(username, email, password, nombreApellidos, vquill) {
    this.username = username;
    this.email = email;
    this.password = password;
    this.nombreApellidos = nombreApellidos;
    this.vquill = vquill;
  }
}
