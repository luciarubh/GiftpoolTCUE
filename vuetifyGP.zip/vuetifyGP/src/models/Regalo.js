export default class Regalo {
  constructor(nombre, cantidad, precioUnidad) {
    this.nombre = nombre;
    this.cantidad = cantidad;
    this.precioUnidad = precioUnidad;
  }
}
