export default class Recaudacion {
  constructor(vquill, nombre, descripcion, fechaFin, foto, tipo, total, regalos) {
    this.vquill = vquill;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.fechaFin = fechaFin;
    this.foto = foto;
	this.tipo = tipo;
	this.total = total;
    this.regalos = regalos;
	// this.motivo = motivo;
  }
}
