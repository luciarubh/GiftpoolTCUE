<script setup>
	import {computed, onMounted, ref} from 'vue';
	import Valoracion from '@/models/Valoracion.js';
	import {useStore} from "vuex";
	import {useRouter} from "vue-router";

	const auth = computed(() => store.state.authenticated)
	const router = useRouter();
	const store = useStore()
	var usuario = ref(null)
	//
	const rating = ref(0);
	const positivo = ref("");
	const mejoras = ref("");
	let snackbar = ref(false);
	let snackbarText = ref("");

	//Comprobar si el usuario esta logueado
	onMounted(async () =>
	{
		try {
			const response = await fetch("http://localhost:8000/api/user",
				{
					headers: {"Content-Type": "application/json"},
					credentials: "include"
				})
			if (response.status != 401)
			{
				await store.dispatch("setAuth", true)
				//Obtener los datos del usuario
				try {
					const response = await fetch("http://localhost:8000/api/user", {
						headers: {"Content-Type": "application/json"},
						credentials: "include"
					})
					if (response.status != 401) {
						usuario.value = await response.json()                     //Datos del usuario almacenados en la variable local de usuario
					}
				} catch (e) {console.log(e.message)}
			}
		} catch (e) {await store.dispatch("setAuth", false)}
	})

	//Enviar valoracion al servidor y redirigir a la pagina principal
	async function enviar()
	{
		//Comprobar que los campos no están vacios
		if (positivo.value === "" || mejoras.value === "" || rating.value == 0)
		{
			snackbarText.value = "Los campos no pueden estar vacios";
			snackbar.value = true;
		}
		//En el caso de que sean correctos
		else
		{
			const fecha = Date.now()
			const val = new Valoracion(rating.value, positivo.value, mejoras.value, usuario.value._id, usuario.value.username, fecha);
			const response = await fetch("http://localhost:8000/api/valoracion",
			{
					method: "POST",
					headers: {"Content-Type": "application/json",},
					credentials: 'include',
					body: JSON.stringify
					({
						valoracion: val,
					}),
			});
			router.push("/");
		}
	}
</script>

<template>
		<!--LOGIN INCORRECTO-->
		<p class="pAuthFail" align="center" v-if="!auth">
			<LoginFail></LoginFail>
		</p>
		<!--LOGIN CORRECTO-->
		<div class="text-center" v-if="auth">
			<v-container style="padding: 0; margin-top: 20px;">
				<!--Titulo-->
				<v-row align="center" style="padding: 0; margin: 0px;">
					<v-col style="padding: 0; margin: 0px;">
						<p class="pregunta" style="margin: 0px; padding: 0;">¿Que puntuación le das a Giftpool?</p>
					</v-col>
				</v-row>
				<!--Estrellas-->
				<v-row align="center" style="padding: 0; margin: 0px;">
					<v-col style="padding: 0; margin: 0px;">
						<v-rating v-model="rating" active-color="orange-lighten-1" color="orange-lighten-1" style="margin: 0px; padding: 0;" ></v-rating>
					</v-col>
				</v-row>
				<!--Positivo-->
				<v-row style="padding: 0; margin: 0px;">
					<v-col style="padding: 0; margin: 0px;">
						<v-textarea v-model="positivo" prepend-inner-icon="mdi-check-decagram-outline" label="¿Que te gusta actualmente?" variant="outlined" style="margin-left: 20px; margin-right: 20px;" rows="6"></v-textarea>
					</v-col>
				</v-row>
				<!--Negativo-->
				<v-row style="padding: 0; margin: 0px;">
					<v-col style="padding: 0; margin: 0px;">
						<v-textarea v-model="mejoras" prepend-inner-icon="mdi-alert-decagram" label="¿Que mejorarías?" variant="outlined" style="margin-left: 20px; margin-right: 20px;" rows="6"></v-textarea>
					</v-col>
				</v-row>
				<!--Info Valoracion-->
				<v-row  style="padding: 0; margin: 0px;">
					<v-col  style="padding: 0; margin: 0px;">
						Tu valoracion: {{rating}}★
					</v-col>
				</v-row>
				<!--Boton enviar-->
				<v-row style="padding: 0; margin: 0px;">
					<v-col style="padding: 0; margin: 0px;">
						<v-btn @click="enviar()" prepend-icon="mdi-email-arrow-right" style="background-color: #AF091D; color: white; font-weight: bold;  font-size: 14px; padding: 10px; height: auto; margin-top: 10px;">Enviar valoracion</v-btn>
					</v-col>
				</v-row>
			</v-container>
		</div>
</template>

<style scoped>
.pregunta
{
	font-size: 20px;
	font-weight: bold;
	margin: 20px;
}
</style>
