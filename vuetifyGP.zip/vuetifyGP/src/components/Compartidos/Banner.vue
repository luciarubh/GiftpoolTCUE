<script setup>
	import {computed, onMounted, ref} from "vue";
	import store from "@/store";

	let usuarioLogeado = ref(computed(() => store.state.usuarioLogeado))
	let quillUser = computed(() => usuarioLogeado.value ? usuarioLogeado.value.vquill : '')
</script>

<template>
	<v-card elevation="0" style="height: auto; background-color: #F2F2F2; margin-top: 5px;">
  		<span v-html="quillUser" style="padding: 10px;"></span>
  	</v-card>
</template>

<style>
</style>
