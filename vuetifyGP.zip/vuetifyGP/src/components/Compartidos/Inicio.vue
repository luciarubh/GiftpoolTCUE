<script setup>
	import {ref, onMounted, computed} from 'vue'
	import { useStore } from 'vuex'
	import PrevisualizacionRecaudacion from '@/components/Recaudacion/PrevisualizacionRecaudacion.vue'
	import {useRouter} from "vue-router";

	const store = useStore()
	const router = useRouter()
	//
	let recSeleccionada = ref(null)
	var ListaRecaudaciones = ref([]);
	const valor = ref(0)

	//Comprobar si el usuario esta logueado y obtener las recaudaciones publicas (visibles para todos los usuarios, logueados o no)
	onMounted(async () =>
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/user",
			{
				headers: { "Content-Type": "application/json" },
			  	credentials: "include"
			})
			const resp = await response.json();
			if (response.status != 401)
			{
				await store.dispatch('setUsuarioLogeado', resp)
				await store.dispatch("setAuth", true)
			}
		} catch (e) { await store.dispatch("setAuth", false)  }
		//Consultar las recaudaciones publicas
		try
		{
			const response = await fetch("http://localhost:8000/api/recaudacionesPublicas",
			{
				headers: {
					"Content-Type": "application/json" },
				credentials: "include",
			})
			const resp = await response.json();
			ListaRecaudaciones.value = resp.message
		} catch (e) {console.log("Algo ha ido mal"); router.push('/NetworkError');}
	})

	//Si se selecciona una recaudacion de la lista, se redirige a la pagina de detalle de recaudacion
	const handleClick = (item) => {
		recSeleccionada.value = item
		router.push({name: 'recaudacion', params: { id: recSeleccionada.value._id } });
	}
</script>

<template>
  <div style="background-color: #AF091F; height:100%; margin-top: 0px;" align="center">
    <h1 align="center" style="margin-bottom: 10px; color:white; font-size: 20px;">Recaudaciones publicas en Giftpool</h1>
    <v-container style="margin:0px; padding: 0px;" align="center">
		  <div style="width: 90%;" v-if="ListaRecaudaciones.length > 0" v-for="item in ListaRecaudaciones">
				<PrevisualizacionRecaudacion v-bind:item="item" @click="() => handleClick(item)" v-if="item && item.estado == 'aceptada'" v-bind:tipo="false" v-bind:tipoRec="false" align="center" v-bind:valor="valor"></PrevisualizacionRecaudacion>
		  </div>
    </v-container>
	<v-container style="margin:0px; padding: 0px;" align="center">
		  <div style="width: 95%;" v-if="ListaRecaudaciones.length == 0">
			  <v-img style="width: 50%;" src="@/assets/CartelCrearRec.png"></v-img>
			  <p style="color: white; font-size: 15px;">Parece que todavía no hay recaudaciones públicas. </p>
			  <p style="color: white; font-size: 15px;">¡Inicia sesión y sé el primero en crear una!</p>
		  </div>
	</v-container>
  </div>
</template>

