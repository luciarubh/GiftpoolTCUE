<template>
  <span class="go-back">
    <v-btn @click="goBack" style="padding-left: 0px;" size="x-small"><v-icon icon="mdi-arrow-left" size="x-large"></v-icon></v-btn>
  </span>
</template>


<script>
  export default
  {
    methods:
    {
      goBack() {
        return this.$router.go(-1)
      }
    }
  }
</script>
