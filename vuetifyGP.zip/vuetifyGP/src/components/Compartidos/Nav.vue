<script>
	import { computed } from 'vue';
  	import { useStore } from 'vuex';
  	import GoBack from '@/components/Compartidos/Volver.vue'

	export default
	{
		components: {
			GoBack
		},
		setup()
		{
			const store = useStore();
		  	const auth = computed(() => store.state.authenticated)
			//Si se selecciona cerrar sesion
			const logout = async () =>
		  	{
				const response = await fetch("http://localhost:8000/api/logout",
			  	{
					method: "POST",
					headers: { "Content-Type": "application/json" },
					credentials: "include"
			  	})
				await store.dispatch("setAuth", false)
		  	}
			return {
				auth,
				logout
			}
		}
	}
</script>

<template>
  <v-app-bar color="#AF091D" :elevation="0" align="center" style="position: fixed;">
    <!--Autenticado: Se el desplegable con las opciones del perfil-->
    <v-app-bar-title style="font-size: 25px; font-weight:500; margin:0px;" align="center" v-if="auth">
      <v-container align="center" style="width: 100%;">
        <v-row align="center">
          <v-col style="padding-left: 0px;" align="left"><GoBack style="margin-left: 0px;" align="left"/></v-col>
          <v-col align="center" style="margin: 0px; padding: 0px;">
            <router-link to="/">
              <v-img :width="50" aspect-ratio="16/9" cover src="@/assets/logo.png"></v-img>
            </router-link>
          </v-col>
          <v-col align="right">
            <!--Men� perfil-->
            <v-menu>
              <template v-slot:activator="{ props }">
                <v-btn v-bind="props" size="x-large" icon="mdi-account-circle-outline"></v-btn>
              </template>
              <v-list>
                <v-list-item style="padding-top: 0px; padding-bottom: 0px; padding-left: 10px; padding-right: 10px; " density="compact">
                  <router-link to="/editarPerfil" style="text-decoration: none; font-size: 13px; color:black;">
					  <v-icon aria-hidden="false">mdi-account-edit</v-icon>
					  <span class="botonesNav" style="color: black;">  Editar perfil</span>
				  </router-link>
                </v-list-item>
                <v-list-item style="padding-top: 0px; padding-bottom: 0px; padding-left: 10px; padding-right: 10px; " density="compact">
					<router-link to="/Home" style="text-decoration: none; font-size: 13px; color:black;">
						<v-icon aria-hidden="false">mdi-account</v-icon>
						<span class="botonesNav" style="color: black;">  Ver perfil</span>
					</router-link>
                </v-list-item>
                <v-list-item style="padding-top: 0px; padding-bottom: 0px; padding-left: 10px; padding-right: 10px; " density="compact">
					<router-link to="/valoranos" style="text-decoration: none; font-size: 13px; color:black;">
						<v-icon aria-hidden="false">mdi-star</v-icon>
						<span class="botonesNav" style="color: black;">  Valoranos</span></router-link>
                </v-list-item>
				<v-list-item style="padding-top: 0px; padding-bottom: 0px; padding-left: 10px; padding-right: 10px; " density="compact">
					<router-link to="/login" @click="logout" style="text-decoration: none; font-size: 13px; color:black;">
						<v-icon aria-hidden="false">mdi-logout-variant</v-icon>
						<span class="botonesNav" style="color: black;">  Cerrar sesion</span>
					</router-link>
				</v-list-item>
              </v-list>
            </v-menu>
          </v-col>
        </v-row>
      </v-container>
    </v-app-bar-title>

    <!--NO autenticado: Se muestra el logo y la opcion de iniciar sesion-->
    <template v-if="!auth" style="margin-bottom: 0px;">
      <v-app-bar-title style="margin-bottom: 0px;">
        <v-container style="padding-left: 4px; margin-bottom:0px;">
          <v-row align="center">
            <v-col align="left">
              <router-link to="/">
                <v-img :width="50" aspect-ratio="16/9" cover src="@/assets/logo.png"></v-img>
              </router-link>
            </v-col>
            <v-col align="right">
              <router-link to="/login" style="text-decoration: none;"><p class="botonesNav">Iniciar Sesion</p></router-link>
            </v-col>
          </v-row>
          </v-container>
       </v-app-bar-title>
    </template>
  </v-app-bar>
</template>

<style>
  .botonesNav {
    text-decoration: none;
    color: white;
    font-weight: 450;
  }
</style>
