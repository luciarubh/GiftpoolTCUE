<script setup>
	import { ref, computed, onMounted } from 'vue';
	import { useStore } from 'vuex';
	import {useRouter} from "vue-router";

	const store = useStore();
	const auth = computed(() => store.state.authenticated);
	const router = useRouter();
	//
	let showPassword = ref(false);
	let email = ref("");
	let password = ref("");
	let snackbar = ref(false);
	let snackbarText = ref("");

	//Si el usuario ya ha iniciado sesion, redirigir a la pagina principal: /
	onMounted(async () => {
		try {
			const response = await fetch("http://localhost:8000/api/user", {
				headers: { "Content-Type": "application/json" },
				credentials: "include"
			});
			if (response.status != 401) {
				await store.dispatch("setAuth", true);
				router.push("/");
			}
		} catch (e) { router.push('/NetworkError'); }
	});

	//Validar que los campos no estén vacios y enviar la peticion de login
	async function login(e)
	{
		//Si los campos no están vacios
		if (email.value != "" && password.value != "")
		{
			e.preventDefault();
			const response = await fetch("http://localhost:8000/api/login",
			{
				method: "POST",
				headers: { "Content-Type": "application/json" },
				credentials: 'include',
				body: JSON.stringify({
					email: email.value,
					password: password.value,
				}),
			});
			//Respuesta
			const status = await response.status;
			const resp = await response.json();
			//200 == usuario encontrado y contrase�a correcta
			if (status == 200)
			{
				const user = resp.message
				store.dispatch('setUsuarioLogeado', user)
				router.push("/");
			}
			//404 == usuario no encontrado - 400 == contrase�a incorrecta
			else
			{
				snackbarText.value = resp.message;
				snackbar.value = true;
			}
		} else
		{
			snackbarText.value = "Los campos no pueden estar vacíos.";
			snackbar.value = true;
		}
	}
	//Si selecciona recuperar contrase�a, redigir a la pagina de recuperacion
	async function recuperarContras()
	{
		router.push("/RecuperarContrasena");
	}
</script>

<template>
	<div style="height: 100%;">
		<div style="background-color: #AF091D; height: 100%; padding-top: 110px; position: initial;" :scrolling-enabled="false" v-if="!auth">
			<v-card class="mx-auto" style="align-content:center; padding: 10px;" elevation="8" width="90%" height="auto" rounded="lg">
				<!--TITULO-->
				<v-card-title class="pb-0" style="margin-bottom: 5px;">
					<h1 style="color: black; font-size: 20px;" align="center">Bienvenido a GiftPool</h1>
				</v-card-title>
				<!--CONTENIDO-->
				<v-card-text style="margin-bottom: 0px; padding-bottom: 0px;">
					<v-form @submit.prevent="login" style="margin-bottom: 0px;">
						<!--Usuario-->
						<div class="text-medium-emphasis" style="margin-top: 10px;">Nombre de usuario</div>
						<v-text-field hide-details="auto" v-model="email" density="compact" placeholder="Introduce tu nombre de usuario" style="margin-bottom: 15px;" prepend-inner-icon="mdi-email-outline" variant="outlined"></v-text-field>
						<!--Contraseña-->
						<div class="text-medium-emphasis d-flex align-center justify-space-between">
							Contraseña
							<a class="text-decoration-none" style="color: #AF091D; font-size: 12px;" @click="recuperarContras" rel="noopener noreferrer" target="_blank">¿Has olvidado tu contraseña?</a>
						</div>
						<v-text-field hide-details="auto" v-model="password" :append-inner-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'" :type="showPassword ? 'text' : 'password'"
													density="compact" placeholder="Introduce tu contraseña" prepend-inner-icon="mdi-lock-outline"
													variant="outlined" @click:append-inner="showPassword = !showPassword" style="margin-bottom:5px;"></v-text-field>
					</v-form>
				</v-card-text>
				<!--Botones-->
				<v-card-actions>
					<v-container style="padding: 0px; font-size: 15px;">
						<v-col>
							<v-row>
								<v-spacer></v-spacer>
								<v-btn type="submit" @click="login" style="background-color: #AF091D; color: white; font-weight: bold; border-color: white; border-width: thin; font-size: 14px; padding: 5px; height: auto; margin-bottom: 5px;">Iniciar Sesion</v-btn>
								<v-spacer></v-spacer>
							</v-row>
							<v-row>
								<v-spacer></v-spacer>
								<router-link to="/register" class="text-decoration-none">
									<a style="color: #AF091D; font-size: 14px; margin-left: 10px;">
										Crear una cuenta<v-icon icon="mdi-chevron-right"></v-icon>
									</a>
								</router-link>
								<v-spacer></v-spacer>
							</v-row>
						</v-col>
					</v-container>
				</v-card-actions>
			</v-card>
			<!-- Mostrar mensaje cuando ocurra algun error -->
			<v-snackbar v-model="snackbar" :timeout="3000" style="margin-bottom: 100px; padding: 20px;" max-width="900px">
				<p style="color: white; font-size: 15px; padding: 0px;"> <v-icon icon="mdi-alert-octagon-outline" style="margin-right: 8px;"></v-icon>{{ snackbarText }}</p>
			</v-snackbar>
		</div>
	</div>
</template>




