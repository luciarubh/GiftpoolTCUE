<script setup>
	import { ref, computed, onMounted } from 'vue';
	import { useStore } from 'vuex';
	import {useRouter} from "vue-router";

	const router = useRouter();
	const store = useStore();
	const auth = computed(() => store.state.authenticated);
	//
	let showPassword = ref(false);
	let username = ref("");
	let password = ref("");
	let email = ref("");
	let nombreApellidos = ref("");
	let password2 = ref("");
	let snackbar = ref(false);
	let snackbarText = ref("");

	//Si el usuario ya ha iniciado sesion, redirigir a la pagina principal: /
	onMounted(async () =>
	{
		try {
			const response = await fetch("http://localhost:8000/api/user", {
				headers: { "Content-Type": "application/json" },
				credentials: "include"
			});
			//Si ya hay un usuario autenticado
			if (response.status != 401)
			{
				await store.dispatch("setAuth", true);
				router.push("/");
			}
		} catch (e) {await store.dispatch("setAuth", false);}
	});

	//Funcion para realizar el registro
	const register = async (e) => {
		//Comprobar que los campos no estén vacios
		if (username.value !== "" && email.value !== "" && password.value !== "" && password2.value !== "" && nombreApellidos.value !== "" && password.value === password2.value)
		{
			e.preventDefault();
			const response = await fetch("http://localhost:8000/api/register", {
				method: "POST",
				headers: {"Content-Type": "application/json"},
				body: JSON.stringify({
					username: username.value,
					email: email.value,
					password: password.value,
					password2: password2.value,
					nombreApellidos: nombreApellidos.value,
					descripcion: "",
				}),
			});
			//Registro correcto
			if (response.status != 400 && response.status != 403)
			{
				snackbarText.value = "Usuario registrado correctamente. Inicie sesión.";
				snackbar.value = true;
				username.value = ""
				email.value = ""
				nombreApellidos.value = ""
				password.value = ""
				password2.value = ""
			}
			//Registro incorrecto
			else if (response.status == 403)
			{
				snackbarText.value = "El nombre de usuario o email ya está en uso. Intentelo con otro";
				snackbar.value = true;
			}
			else
			{
				snackbarText.value = "Ha ocurrido un error en el registro. Intentelo de nuevo.";
				snackbar.value = true;
			}
		}
		//Los campos de la contraseña no coinciden
		else if (password.value !== password2.value)
		{
			snackbarText.value = "La contraseña no coincide";
			snackbar.value = true;
		}
		//Hay algún campo vacio
		else
		{
			snackbarText.value = "Por favor, rellena todos los campos para completar el registro.";
			snackbar.value = true;
		}
	}
</script>


<template>
    <div v-if="!auth" style="background-color:#AF091D ; height: 100%; padding-top: 30px;">
      <!--Card-->
      <v-card class="mx-auto pb-5" elevation="8" max-width="550" rounded="lg" style="padding: 0px 20px;" align="center" width="90%" height="auto">
        <v-card-title align="center" style="nombreregistermargin-bottom: 3px; padding: 5px;">
          <h1 style="color: black; font-size: 20px;" class="display-1">Registrarse</h1>
        </v-card-title>
        <v-card-text style="margin-bottom: 0px; padding: 0px;">
          <v-form @submit.prevent="register">
            <!--Nombre y apellidos-->
            <v-text-field v-model="nombreApellidos" density="compact" variant="outlined">
              <template v-slot:prepend>
                <v-icon icon="mdi-rename-box" />
              </template>
              <template v-slot:label>
                <span style="font-size: 11px; padding: 0px;">Nombre y Apellidos</span>
              </template>
            </v-text-field>
            <!--Username-->
            <v-text-field v-model="username"  density="compact" label="Nombre de Usuario" prepend-icon="mdi-account-circle" variant="outlined">
              <template v-slot:label>
                <span style="font-size: 11px; padding: 0px;">Nombre de usuario</span>
              </template>
            </v-text-field>
            <!--Email-->
            <v-text-field v-model="email" density="compact" label="Email" prepend-icon="mdi-at" variant="outlined" >
              <template v-slot:label>
                <span style="font-size: 11px; padding: 0px;">Email</span>
              </template>
            </v-text-field>
            <!--Contrase�a-->
            <v-text-field v-model="password" density="compact" :type="showPassword ? 'text' : 'password'" @click:append-inner="showPassword = !showPassword" prepend-icon="mdi-lock" :append-inner-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'" variant="outlined">
              <template v-slot:label>
                <span style="font-size: 11px; padding: 0px;">Contrase�a</span>
              </template>
            </v-text-field>
            <!--COnfirmar contrase�a-->
            <v-text-field v-model="password2" :append-inner-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'" :type="showPassword ? 'text' : 'password'" density="compact" label="Repite la contrase�a" prepend-icon="mdi-lock" variant="outlined" @click:append-inner="showPassword = !showPassword">
              <template v-slot:label>
                <span style="font-size: 11px; padding: 0px;">Confirma la contrase�a</span>
              </template>
            </v-text-field>
          </v-form>
        </v-card-text>
        <!--BOTONES-->
        <v-card-actions style="padding: 0px; margin-top: 0px;">
          <v-container style="padding: 0px; font-size: 20px;">
            <v-col>
              <v-row>
                <v-spacer></v-spacer>
                <v-btn type="submit" @click="register" style="background-color: #AF091D; color: white; font-weight: bold; border-color: white; border-width: thin; font-size: 14px; padding: 5px; height: auto;">Registrarse</v-btn>
                <v-spacer></v-spacer>
              </v-row>
              <v-row>
                <v-spacer></v-spacer>
                <router-link to="/login" class="text-decoration-none">
                  <a style="color: #AF091D; font-size: 12px; margin-left: 10px;">
                    Si ya tienes una cuenta, inicia sesion aqui<v-icon size="x-small" icon="mdi-chevron-right"></v-icon>
                  </a>
                </router-link>
                <v-spacer></v-spacer>
              </v-row>
            </v-col>
          </v-container>
        </v-card-actions>
      </v-card>

		<v-snackbar v-model="snackbar" :timeout="3000" style="margin-bottom: 50px; padding: 20px;" max-width="900px">
			<p style="color: white; font-size: 15px; padding: 0px;"> <v-icon icon="mdi-alert-octagon-outline" style="margin-right: 8px;"></v-icon>{{ snackbarText }}</p>
		</v-snackbar>
    </div>
</template>

<style>
</style>

