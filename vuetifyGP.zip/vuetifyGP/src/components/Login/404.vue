<script setup>
</script>

<template>
	<div class="align-center" align="center">
		<v-img style="width: 70vw; margin-top: 30px;" src="@/assets/404.png"></v-img>
		<p style="font-size: 20px; padding: 5px;">Ups, parece que la página a la que quieres acceder no existe</p>
	</div>
</template>

<style scoped>
</style>
