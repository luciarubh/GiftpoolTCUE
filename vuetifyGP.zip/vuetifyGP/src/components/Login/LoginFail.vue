<script setup>
import { useStore } from 'vuex'
import {computed} from "vue";

const store = useStore()
const auth = computed(() => store.state.authenticated);
</script>

<template>
  <v-img style="width: 60%;" src="@/assets/deadpoolStop1.png"></v-img>
  <p style="font-size: 16px;">Parece que no has iniciado sesion.</p>
  <span style="font-size: 16px;">Por favor, </span>
  <router-link style="font-size: 16px;" to="/login" v-if="!auth" class="linkFailAuth">inicia sesion</router-link>
  <span style="font-size: 16px;"> o </span>
  <router-link style="font-size: 16px;" to="/register" v-if="!auth" class="linkFailAuth">crea una cuenta</router-link>
</template>


