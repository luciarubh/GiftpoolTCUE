<script setup>

</script>

<template>
	<div class="align-center" align="center">
		<v-img style="width: 60%; margin-top: 30px;" src="@/assets/netError.png"></v-img>
		<p style="font-size: 16px; padding: 5px;">Giftpool no está disponible en este momento.</p>
		<span style="font-size: 16px; padding: 5px;">Por favor, intentalo de nuevo más tarde. </span>
	</div>
</template>

