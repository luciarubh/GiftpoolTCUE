<script setup>
	import {computed, onMounted, ref} from "vue";

	let porcentaje = ref (null)
	let fechaFormateada = ref('')
	const props = defineProps({
		item: String
	})

	//Con los datos de la recaudacion, calcular el porcentaje de la barra de progreso
	onMounted(async () =>
	{
		porcentaje = computed(() => {
			if(props.item)
			{
				if (props.item.recaudacion.cantidadTotal > 0) {
					return (props.item.recaudacion.cantidadActual / props.item.recaudacion.cantidadTotal) * 100;
				} else {
					return 0;
				}
			}
		});
		//Formatear la fecha de tipo Date a String DD-MM-AAAA
		if(props.item)
		{
			let fecha = new Date(props.item.recaudacion.fechaFin);
			let dia = ("0" + fecha.getDate()).slice(-2);
			let mes = ("0" + (fecha.getMonth() + 1)).slice(-2);
			let ano = fecha.getFullYear();
			fechaFormateada.value = `${dia}/${mes}/${ano}`;
		}
	})
</script>

<template>
  <v-container style="padding: 20px;" class="infoRecaudacion" align="center" >
	  <v-row style="margin-bottom: 20px;">
		  <v-col v-if="props.item && props.item.recaudacion" style="padding: 0px;">
			  <p style="font-size: 20px;"><strong>{{ props.item.recaudacion.nombre }}</strong></p>
		  </v-col>
	  </v-row>
	  <span v-html="props.item.recaudacion.vquill" v-if="props.item && props.item.recaudacion" style="padding: 0px; margin-bottom: 10px;"></span>
    <!--Fecha-->
    <v-row style="margin-top: 5px;">
      <v-col v-if="props.item && props.item.recaudacion" style="padding: 0px;">
        <p v-if="props.item && props.item.recaudacion"  class="fechaRecaudacion">Termina el {{ props.item.recaudacion.fechaFin }}</p>
        <p v-if="props.item && props.item.recaudacion" class="fechaRecaudacion">Se han recaudado {{props.item.recaudacion.cantidadActual}}€ de {{ props.item.recaudacion.cantidadTotal }}€</p>
      </v-col>
    </v-row>
    <!--Barra progreso-->
    <v-row align="center">
        <v-col style="padding:0px;" align="center">
            <v-progress-linear align="center" v-model="porcentaje" height="25" color="green">
              <strong>{{ Math.ceil(porcentaje) }}%</strong>
            </v-progress-linear>
        </v-col>
    </v-row>
  </v-container>
</template>



<style>
  .infoRecaudacion
  {
    height: auto;
    width: 50vh;
  }
  .fechaRecaudacion
  {
    font-style: italic;
    font-size: 16px;
  }
</style>
