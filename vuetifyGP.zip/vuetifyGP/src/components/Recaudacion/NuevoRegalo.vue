<script setup>
	import { watch } from 'vue';
	import Regalo from "../../models/Regalo";

	let props = defineProps({ nuevoRegalo: Regalo, cantidadTotal: Number })

	//Recalcular la cantidadTotal cuando se modifquen los campos de cantidad y precio
	watch(() => [props.nuevoRegalo.cantidad, props.nuevoRegalo.precioUnidad], async ([cantidad, precioUnidad]) => {
		cantidad = Number(cantidad);
		precioUnidad = Number(precioUnidad);
		let res = Number(cantidad * precioUnidad);
	}, { immediate: true });


</script>

<template>
	<v-container style="padding: 0px; margin: 0px;">
		  <v-row align="center" style="width: 100%">
			<v-col>
			  <v-row>
				<v-text-field v-model="props.nuevoRegalo.nombre" prepend-inner-icon="mdi-gift-outline" label="Nombre" density="compact" variant="underlined" style="width:30%; margin:0px; margin-right: 10px;"> </v-text-field>
				<v-text-field v-model="props.nuevoRegalo.cantidad" prepend-inner-icon="mdi-cart-minus" label="Unidades" density="compact" variant="underlined" style="width: 10%; margin: 0px; margin-right: 10px; "> </v-text-field>
				<v-text-field v-model="props.nuevoRegalo.precioUnidad" prepend-inner-icon="mdi-currency-eur" label="Precio/Unidad" density="compact" variant="underlined" style="width: 15%; margin: 0px; "> </v-text-field>
			  </v-row>
			</v-col>
		  </v-row>
	</v-container>
</template>

