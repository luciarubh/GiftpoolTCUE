<script setup>
	import { useRouter } from 'vue-router'
	import {onMounted, ref} from "vue";
	import { useStore } from "vuex"

	const router = useRouter()
	const store = useStore()
	var usuario = ref(null)

	//Autenticacion del usuario
	onMounted(async () =>
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/user",
			{
					headers: {"Content-Type": "application/json"},
					credentials: "include"
			})
			if (response.status != 401)
			{
				await store.dispatch("setAuth", true)
				//Obtener los datos del usuario
				try {
					const response = await fetch("http://localhost:8000/api/user", {
						headers: {"Content-Type": "application/json"},
						credentials: "include"
					})
					if (response.status != 401) {
						usuario.value = await response.json()
					}
				} catch (e) {console.log(e.message); router.push('/NetworkError'); }
			}
		} catch (e) {
			router.push('/NetworkError');
		}
	})

	//Una vez realizado el pago, redirigir a la pagina principal
	async function guardar()
	{
		router.push('/home');
	}

</script>

<template>
	<v-container align="center">
		<v-img style="width: 90%; padding: 0px; margin-top: 20px;" src="@/assets/PaypalGif.gif"></v-img>
		<p>El pago se ha realizado correctamente.</p>
		<p>¡Muchas gracias por tu aportación!</p>
		<v-btn style="background-color: #00457C; color: white; margin-top: 20px;" v-on:click="guardar" prepend-icon="mdi-account-circle-outline">Volver a tu perfil</v-btn>
	</v-container>
</template>

<style scoped>

</style>
