<script setup>
	import {onMounted, ref, computed, defineProps} from "vue"
	import { useStore } from "vuex"
	import { useRouter } from 'vue-router'
	import { useClipboard } from '@vueuse/core'

	const router = useRouter()
	const store = useStore()
	const source = computed(() => window.location.href)
	const { text, copy, copied, isSupported } = useClipboard({ source })
	//
	let rec = ref("")
	let apor = ref("")
	var usuario = ref(null)
	let recSeleccionada = ref(null)
	const props = defineProps({
		id: String
	})

	onMounted(async () =>
	{
		//Autenticacion del usuario
		try
		{
			const response = await fetch("http://localhost:8000/api/user",
			{
					headers: { "Content-Type": "application/json" },
					credentials: "include"
			})
			if (response.status != 401)
			{
				await store.dispatch("setAuth", true)
				//Obtener los datos del usuario
				try
				{
					const response = await fetch("http://localhost:8000/api/user", {
						headers: { "Content-Type": "application/json" },
						credentials: "include"
					})
					if (response.status != 401) {
						usuario.value = await response.json()
					}
				} catch (e) {console.log(e.message) }
			}
		} catch (e) {await store.dispatch("setAuth", false)}

		//Obtener los datos de la recaudacion
		try
		{
			const id = props.id;
			fetch(`http://localhost:8000/api/recaudacion/${id}`,
			{
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
				},
			}).then(response => response.json())
			  .then(data => {rec.value = data;})
			  .catch((error) => { console.error('Error:', error); });
		} catch (e) {console.log(e.message); router.push('/NetworkError');}

		//Obtener aportaciones de la recaudacion
		try
		{
			const idRec = props.id;
			fetch("http://localhost:8000/api/aportacionesRecaudacion",
			{
				method: "POST",
				headers: { "Content-Type": "application/json" },
				credentials: 'include',
				body: JSON.stringify({ id: idRec })
			}).then(response => response.json())
				.then(data => {apor.value = data.message;})
				.catch((error) => { console.error('Error:', error); router.push('/NetworkError'); });
		} catch (e) {console.log(e.message)}
	})

	//Si se selecciona editar la recaudacion (solo si es el usuario creador)
	const handleClick = (rec) => {
		recSeleccionada.value = rec.recaudacion
		router.push({name: 'editarRecaudacion', params: { id: recSeleccionada.value._id } });
	}
</script>

<template>
  <div>
    <v-container align="center" class="divGlobal" style="width: 90%;">
		<!--Boton para editar la recaudacion: Solo si es del usuario-->
			<v-row align="center">
				<v-col>
					<div v-if="usuario">
						<v-btn v-if="rec && rec.recaudacion && usuario._id == rec.recaudacion.userId" prepend-icon="mdi-pencil" style="border: 1px solid green; color: green; text-transform: none;" @click="() => handleClick(rec)">Editar recaudacion</v-btn>
						<div v-if="isSupported">
							<v-btn style="background-color: white; color: #00457C; border: solid 1px #00457C; margin-top: 10px; text-transform: none;"  @click="copy(source)">
								<span v-if="!copied"> <span style="margin-right: 5px;" class="mdi mdi-link-variant"/>Copiar enlace de unión</span>
								<span v-else><span style="margin-right: 5px;" class="mdi mdi-clipboard-check-multiple-outline"></span>Copiado en el portapapeles</span>
							</v-btn>
						</div>
						<p v-else>Tu navegador no soporta la copia de enlaces.</p>
					</div>
				</v-col>
			</v-row>

      <v-row align="center" style="padding: 0px;">
        <v-col align="center" style="padding: 0px;">
          <InfoRecaudacion v-bind:item="rec" style="width:100%;" align="center"/>
        </v-col>
      </v-row>
      <v-row align="center" v-for="regalo in rec.regalos" >
        	<Regalo v-bind:item="regalo" v-bind:estadoRec="rec.recaudacion.estado" v-bind:recaudacion="rec.recaudacion._id"/>
      </v-row>
		<div v-if="rec && rec.recaudacion && rec.recaudacion.estado != 'denegada'">
			  <v-row style="background-color: #AF091D; width: 100%; margin-top: 15px;">
				<v-col style="padding: 0px;">
				  <p class="textoSeccionAportaciones">APORTACIONES</p>
				</v-col>
				</v-row>
			  <v-row style="width: 100%;">
				<v-col>
					<v-row align="center" v-if="apor.length == 0">
						<v-col>
							<p>Vaya, de momento no se han recibido aportaciones :(</p>
						</v-col>
					</v-row>
					<v-row><Aportacion v-for="a in apor" v-bind:aportacion="a" style="width: 100%; height: auto;" /></v-row>
				</v-col>
			  </v-row>
		</div>
		<div v-if="rec && rec.recaudacion && rec.recaudacion.estado == 'denegada'">
			<v-row style="background-color: #AF091D; width: 100%; margin-top: 15px;">
				<v-col style="padding: 0px;">
					<p class="textoSeccionAportaciones">Motivo de la denegación</p>
				</v-col>
			</v-row>
			<v-row style="width: 100%; margin-top: 15px;">
				<p>"{{rec.recaudacion.motivo}}"</p>
			</v-row>
			<v-row style="width: 100%; margin-top: 15px; padding: 0px;" align="center">
				<v-col style="padding: 0;">
					<p><em>Por favor, revise los datos y el administrador la revisará de nuevo.</em></p>
				</v-col>
			</v-row>
		</div>
    </v-container>
  </div>
</template>

<style>
	.divGlobal{
		margin-top: 25px;
		border: solid;
		border-radius: 20px;
		border-width: 3Px;
		border-color: #AF091D;
		margin-bottom: 25px;
	}
	.textoSeccionAportaciones
	{
		color: white;
		font-size: 24px;
		background-color: #AF091D;
	}
</style>

