<script setup>
	const props = defineProps({
		item: Object,
		recaudacion: String,
		estadoRec: String
	})

	//Si se pulsa el boton de aportar, se redirige a PayPal
	async function buy(e)
	{
		let regalo = JSON.stringify(props.item);
		let response = null;
		//Llamada a la API
		fetch('http://localhost:8000/api/buy', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			credentials: 'include',
			body: regalo
		})
			.then(response =>				//Fallo
			{
				if (!response.ok) {
					throw new Error('Network response was not ok ' + response.statusText);
				}
				return response.json();
			})
			.then(data =>					//Exito
			{
				const redirectUrl = data.redirectUrl;
				if (redirectUrl) {
					window.location.href = redirectUrl; // Redirigir al usuario a PayPal
				}
				else
				{
					console.error('No redirect URL found');
				}
			}).catch(error => { console.error('There has been a problem with your fetch operation:', error); });
	}
</script>

<template>
    <v-container class="containerRegalo" style=" width: 95%;">
      <v-row align="center" style="width: 100%;">
        <v-col cols="8" style="padding-left: 15px;" align="center">
          <v-row><p class=" textoRegalo tituloRegalo">{{props.item.nombre}} ({{props.item.cantidad}})</p></v-row>
			<v-row><p class="textoRegalo ">Precio/Unidad:&nbsp;&nbsp;</p><p class="textoRegalo numeroTotalRegalo"> {{props.item.precioUnidad}}€</p></v-row>
          <v-row><p class="textoRegalo ">Total:&nbsp;&nbsp;</p><p class="textoRegalo numeroTotalRegalo"> {{props.item.precioTotal}}€</p></v-row>
        </v-col>
        <v-col cols="4" align="right" style="padding:0px;" v-if="estadoRec && estadoRec == 'aceptada' && props.item.cantidad > 0">
			<v-btn color="#fbd344" @click="buy" style="text-transform: none;">
				<v-img style="width: 30%;" src="@/assets/PaypalBoton.png"></v-img>
				Aportar
			</v-btn>
        </v-col>
		  <v-col cols="4" align="center" style="padding:0px;" v-if="estadoRec && estadoRec == 'aceptada' && props.item.cantidad == 0">
			  <span class="mdi mdi-gift-open-outline"></span>Conseguido
		  </v-col>
      </v-row>
    </v-container>
</template>

<style>
  .containerRegalo
  {
    width: 90%;
    height: auto;
    padding: 16px;
    background-color: lightgray;
    border-radius: 15px;
    margin-bottom: 15px;
  }
  .tituloRegalo
  {
    font-weight: 600;
  }
  .textoRegalo
  {
      font-size: 18px;
  }
  .numeroTotalRegalo
  {
    color: #AF091D;
    font-weight: 500;
  }
</style>
