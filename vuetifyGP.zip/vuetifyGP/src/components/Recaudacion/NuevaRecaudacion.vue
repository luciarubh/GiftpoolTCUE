<script setup>
	import { ref, onMounted, watch, computed} from 'vue'
  	import { useStore } from "vuex"
	import { useRouter } from 'vue-router';
	import Recaudacion from '../../models/Recaudacion';
	import Regalo from '../../models/Regalo';
	import NuevoRegalo from "@/components/Recaudacion/NuevoRegalo.vue";
	import LoginFail from "@/components/Login/LoginFail.vue";

	const store = useStore()
	const router = useRouter();
	const usuarioLogeado = ref(computed(() => store.state.usuarioLogeado))
	const auth = computed(() => store.state.authenticated)
	//
	let snackbar = ref(false)
	let snackbarText = ref("")
	//Nombre, descripcion, tipo y Quill
	let quillRecaudacion = ref(usuarioLogeado.value ? usuarioLogeado.value.vquill : '')
	const nombre = ref("")
	const descripcion = ref("")
	const tipo = ref("")
	//Fecha y calendario
	const fechaFin = ref(null)
	const fechaFormateada = computed(() => {
		if (fechaFin.value) {
			return format(new Date(fechaFin.value), 'dd-MM-yyyy')
		}
			return ''
	})
	let menu = ref(false);
	//Imagen
	let image = ref(null);
	let base64 = ref(null);
	watch(image, (newVal) => {
		if(newVal) {
			createBase64Image(newVal[0]);
		} else {
			base64.value = null;
		}
	});
	//Regalos
	const items = ref([])
	let position = ref(0);
	let cantidadTotal =ref(0);

	//Controlar si se añade un nuevo regalo a la lista y recalcular la cantidad total
	watch(items.value, (newVal, oldVal) =>
	{
		cantidadTotal.value = 0
		items.value.forEach(function(regalo)
		{
			if(regalo.cantidad == null || regalo.cantidad == 0 || regalo.precioUnidad == null || regalo.precioUnidad == 0)
			{
				cantidadTotal.value += 0
			}
			else {
				cantidadTotal.value += (regalo.cantidad * regalo.precioUnidad)
			}
		});

	});

	//Comprobar si el usuario esta logueado
	onMounted(async () =>
	{
		try
		{
		  const response = await fetch("http://localhost:8000/api/user",
			{
			  headers: { "Content-Type": "application/json" },
			  credentials: "include"
			})

		  if (response.status != 401) {
			await store.dispatch("setAuth", true)
		  }
		} catch (e) { router.push('/NetworkError');}
	})

	//Funcion para parsar la foto a base64
	function createBase64Image(FileObject)
	{
		const reader = new FileReader();
		reader.onload = (event) => {
			base64.value = event.target.result;
		}
		reader.readAsDataURL(FileObject);
	}
	//Crear nuevo objeto regalo y añadirlo a la lista
	function FuncNuevoRegalo()
	{
		position.value++
		var regalo = new Regalo()
		items.value.push(regalo);
		position.value = items.value.length;
	}
	//Peticion al servidor
	async function crearRecaudacion()
	{
		let total = 0;
		//Llamada a la API para crear la recaudacion: Credenciales y el objeto Recaudacion
		let recaudacion = new Recaudacion(quillRecaudacion.value, nombre.value, descripcion.value, fechaFin.value, base64.value, tipo.value, cantidadTotal.value ,items.value)
		try {
			await fetch("http://localhost:8000/api/crearRecaudacion", // Asegúrate de cambiar esta URL a la correcta
				{
					method: "POST",
					headers: {"Content-Type": "application/json",},
					credentials: 'include',
					body: JSON.stringify
					({
						recaudacion: recaudacion,
					}),
				}).then(router.push('/home'))
				.then(snackbarText = "")
				.then(snackbar = true);
		}catch (e){router.push('/NetworkError');}
  	}

	//Funciones para controlar si se abre o se cierra el calendario
	function abrirCal()  {menu.value = true;}
	function cerrarCal()  {menu.value = false; }
</script>



<template>
	<!--NO AUTORIZADO-->
	<p class="pAuthFail" align="center" v-if="!auth">
		<LoginFail></LoginFail>
	</p>
	<!--AUTORIZADO-->
	<div style="border: none; padding: 0; width: 100vw;" v-if="auth">
    	<v-container style="padding: 0; margin-top: 15px; width: 90vw; border: none;" align="center">
      		<p align="center" style=" background-color: #AF091D ; color: white; font-size: 20px; border-radius: 5px; margin-bottom: 15px; margin-top: 10px;">Nueva recaudacion</p>
      		<!--Nombre y fecha-->
      		<v-row style="width: 100%;" align="center">
				<v-col align="center" style="padding: 0px;">
					<p align="left">Banner de la recaudacion</p>
				  	<quill-editor v-model:content="quillRecaudacion" content-type="html" theme="snow" toolbar="full" style="width:100%; margin-bottom: 10px;"></quill-editor>
				</v-col>
      		</v-row>
			<!-- Nombre -->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-text-field prepend-inner-icon="mdi-rename-box" v-model="nombre" label="Nombre de la recaudacion" density="compact" variant="outlined"></v-text-field>
			</v-row>
			<!-- Descripción -->
			<v-row align="center" style="padding: 0px;  width: 100%;">
				<v-text-field prepend-inner-icon="mdi-text-box-edit" v-model="descripcion" label="Descripción de la recaudación" density="compact" variant="outlined"></v-text-field>
			</v-row>
			<!-- Fecha -->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-text-field readonly v-on:click="abrirCal" prepend-inner-icon="mdi-calendar-month" v-model="fechaFormateada" label="Fecha de fin" density="compact" variant="outlined"></v-text-field>
				<v-date-picker hide-header="hide-header" prepend-inner-icon="mdi-calendar-month" v-on:update:model-value="cerrarCal" v-if="menu === true" v-model="fechaFin" max="2026-01-01" min="2024-04-01" width="100%" ></v-date-picker>
			</v-row>
			<!--Imagen-->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-file-input prepend-icon="" prepend-inner-icon="mdi-paperclip" density="compact" variant="outlined" label="Imagen para la portada" v-model="image"/>
			</v-row>
			<!--Tipo-->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-select prepend-inner-icon="mdi-earth" density="compact" variant="outlined" label="Tipo" :items="[ 'Publica (Todo el mundo)', 'Privada (Por enlace)']" v-model="tipo"
				></v-select>
			</v-row>
			<!-- REGALOS -->
			<v-row align="center" style="padding: 0px; width: 90%;">
				<!-- Boton a�adir regalo -->
				<v-col style="padding: 0px;">
					<v-btn elevation="0" variant="outlined" density="compact" prepend-icon="mdi-plus" v-on:click="FuncNuevoRegalo()" class="btnAddRegalo">Añadir regalo</v-btn>
				</v-col>
				<!-- Regalo -->
				<v-col cols="12" v-for="(regalo, index) in items" :key="index">
					  <NuevoRegalo :nuevoRegalo="regalo"></NuevoRegalo>
				</v-col>
			</v-row>
			<v-row align="center" style="padding: 0px; width: 90%;">
				<v-divider style="width: 100%; padding: 0px;"></v-divider>
				<!-- Total -->
				<v-row class="textTotal">
					<v-col align="Right">
						<p><strong>Total</strong> {{cantidadTotal}}€</p>
					</v-col>
				</v-row>
			</v-row>
			<v-row>
				<v-col>
				  <v-btn type="submit" class="btnEditarPerfil" v-on:click="crearRecaudacion()" prepend-icon="mdi-content-save">Crear recaudacion</v-btn>
				</v-col>
			</v-row>
		</v-container>
	</div>
	<v-snackbar v-model="snackbar" :timeout="3000" style="margin-bottom: 100px; padding: 20px;" max-width="900px">
		<p style="color: white; font-size: 15px; padding: 0px;"> <v-icon icon="mdi-alert-octagon-outline" style="margin-right: 8px;"></v-icon>{{ snackbarText }}</p>
	</v-snackbar>
</template>


<style>
  .btnAddRegalo {
    margin-top: 0px;
    margin-bottom: 25px;
    border: solid 2px #AF091D;
    color: #AF091D;

  }
  .textTotal
  {
    font-size: 16px;
    color: grey;
  }
</style>

