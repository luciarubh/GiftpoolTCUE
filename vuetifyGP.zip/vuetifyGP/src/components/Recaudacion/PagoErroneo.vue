<script setup>
	import { useRouter } from 'vue-router'
	import { useStore } from "vuex"
	import {onMounted, ref} from "vue";

	const router = useRouter()
	const store = useStore()
	var usuario = ref(null)

	//Autenticacion del usuario
	onMounted(async () =>
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/user",
				{
					headers: {"Content-Type": "application/json"},
					credentials: "include"
				})
			if (response.status != 401) {
				await store.dispatch("setAuth", true)
				//Obtener los datos del usuario
				try {
					const response = await fetch("http://localhost:8000/api/user", {
						headers: {"Content-Type": "application/json"},
						credentials: "include"
					})
					if (response.status != 401) {
						usuario.value = await response.json()                     //Datos del usuario almacenados en la variable local de usuario
					}
				} catch (e) {console.log(e.message); router.push('/NetworkError');}
			}
		} catch (e) {
			router.push('/NetworkError');
		}
	})
	//Redirigir a la pagina principal
	async function guardar()
	{
		router.push('/home');
	}

</script>

<template>
	<v-container align="center">
		<v-img style="width: 30%; margin-top: 50px;" src="@/assets/Error.png"></v-img>
		<p>Ha ocurrido un error al procesar el pago.</p>
		<p>Por favor, vuelve a intentarlo.</p>
		<v-btn style="background-color: #00457C; color: white; margin-top: 20px;" v-on:click="guardar" prepend-icon="mdi-account-circle-outline">Volver a tu perfil</v-btn>
	</v-container>
</template>

<style scoped>

</style>
