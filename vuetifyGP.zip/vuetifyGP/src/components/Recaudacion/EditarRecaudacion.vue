<script setup>
	import {ref, onMounted, watch, computed, defineProps} from 'vue'
	import { useStore } from "vuex"
	import { useRouter } from 'vue-router';
	import Regalo from '../../models/Regalo';
	import NuevoRegalo from "@/components/Recaudacion/NuevoRegalo.vue";
	const props = defineProps({
		id: Object
	})

	const store = useStore()
	const router = useRouter();
	var usuarioLogeado = ref(computed(() => store.state.usuarioLogeado))
	const auth = computed(() => store.state.authenticated)
	//
	let rec = ref("")
	var menu = ref(false);
	var usuario = ref(null)
	let snackbar = ref(false);
	let snackbarText = ref("");
	//Imagen
	let image = ref(null);
	let base64 = ref(null);
	watch(image, (newVal) => {
		if(newVal) {
			createBase64Image(newVal[0]);
		} else {
			base64.value = null;
		}
	});
	//Regalos
	const items = ref([])
	let position = ref(0);
	let cantidadTotal =ref(0);
	let cantidadTotalR = ref(0)

	//Controlar si se añade un nuevo regalo a la lista y recalcular la cantidad total
	watch(rec.value, () =>
	{
		cantidadTotal.value = 0
		items.value.forEach(function(regalo)
		{
			if(regalo.cantidad == null || regalo.cantidad == 0 || regalo.precioUnidad == null || regalo.precioUnidad == 0)
			{
				cantidadTotal.value += 0
			}
			else {
				cantidadTotal.value += (regalo.cantidad * regalo.precioUnidad)
			}
		});
	});

	//Comprobar si el usuario esta logeado y si es el propietario de la recaudacion
	onMounted(async () =>
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/user",
				{
					headers: { "Content-Type": "application/json" },
					credentials: "include"
				})
			if (response.status != 401)
			{
				usuario.value = await response.json()
				if (usuario.value._id === usuarioLogeado.value._id)
				{
					await store.dispatch("setAuth", true)
				}
				else
				{
					router.push("/");
				}
			}
			else {
				await store.dispatch("setAuth", false)
			}
		} catch (e) { router.push("/"); }

		//Obtener datos de la recaudacion
		try
		{
			const id = props.id;
			fetch(`http://localhost:8000/api/recaudacion/${id}`,
			{
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
				},
			}).then(response => response.json())
			  	.then(data => {rec.value = data; })
				.then(() =>{
					if (rec.value.recaudacion.tipoRecaudacion == 0) rec.value.recaudacion.tipoRecaudacion = "Privada (Por enlace)"
					else rec.value.recaudacion.tipoRecaudacion = "Publica (Todo el mundo)"
				})
				.then(() => {
					rec.value.recaudacion.fechaFin = new Date(rec.value.recaudacion.fechaFin);
				})
				.catch((error) => { console.error('Error:', error); router.push('/NetworkError');});
		} catch (e) {}
	})
	//Recalcular la cantidad total
	function recalcular()
	{
		rec.value.recaudacion.cantidadTotal = 0;
		rec.value.regalos.forEach(function(regalo)
		{
			if(regalo.cantidad == null || regalo.cantidad == 0 || regalo.precioUnidad == null || regalo.precioUnidad == 0)
			{
				rec.value.recaudacion.cantidadTotal += 0
			}
			else {
				rec.value.recaudacion.cantidadTotal += (regalo.cantidad * regalo.precioUnidad)
			}
		});
	}

	//Funcion para pasar la foto a base64
	function createBase64Image(FileObject)
	{
		const reader = new FileReader();
		reader.onload = (event) => {
			base64.value = event.target.result;
		}
		reader.readAsDataURL(FileObject);
	}
	//Crear nuevo objeto regalo y añadirlo a la lista
	function FuncNuevoRegalo()
	{
		position.value++
		let regalo = new Regalo()
		rec.value.regalos.push(regalo);
		position.value = items.value.length;
	}
	//Enviar los datos modificados al servidor
	async function editarRecaudacion()
	{
		try
		{
			await fetch("http://localhost:8000/api/editarRecaudacion",
			{
				method: "POST",
				headers: {"Content-Type": "application/json",},
				credentials: 'include',
				body: JSON.stringify
				({
					recaudacion: rec.value.recaudacion,
					regalos: rec.value.regalos
				}),
			}).then(router.push('/home'));
		}catch (e) {console.log(e.message); router.push('/NetworkError');}
	}
	//Si el usuario selecciona eliminar la recaudacion. Si la recaudacion ha tenido aportaciones, no se puede eliminar
	//hasta que esté terminada
	async function eliminarRecaudacion()
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/eliminarRecaudacion",
				{
					method: "POST",
					headers: {"Content-Type": "application/json",},
					credentials: 'include',
					body: JSON.stringify
					({
						recaudacion: rec.value.recaudacion
					}),
				})
			if (response.status == 200)
			{
				router.push('/home');
			}
			else
			{

				snackbarText.value = "La recaudacion tiene que estar terminada para poder eliminarla.";
				snackbar.value = true;
			}
		}catch (e) {console.log(e.message); router.push('/NetworkError');}
	}

	//Eliminar regalo de la lista
	function borrarRegalo(index){
		rec.value.regalos.splice(index, 1);
	}
	//Funciones para controlar el calendario
	function abrirCal()  {menu.value = true;}
	function cerrarCal()  {menu.value = false; }
</script>



<template>
	<!--LOGIN INCORRECTO-->
	<p class="pAuthFail" align="center" v-if="!auth">
		<LoginFail></LoginFail>
	</p>
	<!--LOGIN CORRECTO-->
	<div v-if="rec && auth" style="border: none; padding: 0; width: 100vw; height: auto;">
		<v-container style="padding: 0; margin-top: 15px; width: 90vw; border: none;" align="center">
			<p align="center" style=" background-color: #AF091D ; color: white; font-size: 20px; border-radius: 5px; margin-bottom: 15px; margin-top: 10px;">Nueva recaudacion</p>
			<!--Nombre y fecha-->
			<v-row style="width: 100%;" align="center">
				<v-col align="center" style="padding: 0px;">
					<p align="left">Banner de la recaudacion</p>
					<quill-editor v-model:content="rec.recaudacion.vquill" content-type="html" theme="snow" toolbar="full" style="width:100%; margin-bottom: 10px;"></quill-editor>
				</v-col>
			</v-row>
			<!-- Nombre -->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-text-field prepend-inner-icon="mdi-rename-box" v-model="rec.recaudacion.nombre" label="Nombre de la recaudacion" density="compact" variant="outlined"></v-text-field>
			</v-row>
			<!-- Descripción -->
			<v-row align="center" style="padding: 0px;  width: 100%;">
				<v-text-field prepend-inner-icon="mdi-text-box-edit" v-model="rec.recaudacion.descripcion" label="Descripción de la recaudación" density="compact" variant="outlined"></v-text-field>
			</v-row>
			<!-- Fecha -->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-text-field readonly v-on:click="abrirCal" prepend-inner-icon="mdi-calendar-month" v-model="rec.recaudacion.fechaFin" label="Fecha de fin" density="compact" variant="outlined"></v-text-field>
				<v-date-picker hide-header="hide-header" prepend-inner-icon="mdi-calendar-month" v-on:update:model-value="cerrarCal" v-if="menu === true" v-model="rec.recaudacion.fechaFin" max="2026-01-01" min="2024-04-01" width="100%" ></v-date-picker>
			</v-row>
			<!--Imagen-->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<p style="color: gray; font-style: italic;">Imagen actual: </p>
				<img :src="rec.recaudacion.imagen" style="width: 50px; margin-bottom: 15px;" alt="Imagen actual">
			</v-row>
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-file-input prepend-icon="" prepend-inner-icon="mdi-paperclip" density="compact" variant="outlined" label="Introduce la nueva imagen"/>
			</v-row>
			<!--Tipo-->
			<v-row align="center" style="padding: 0px; width: 100%;">
				<v-select prepend-inner-icon="mdi-earth" density="compact" variant="outlined" label="Tipo" :items="[ 'Publica (Todo el mundo)', 'Privada (Por enlace)']" v-model="rec.recaudacion.tipoRecaudacion"
				></v-select>
			</v-row>
			<!-- Boton a�adir regalo -->
			<v-row align="center" style="padding: 0px; width: 90%;">
				<v-col style="padding: 0px;">
					<v-btn elevation="0" variant="outlined" density="compact" prepend-icon="mdi-plus" v-on:click="FuncNuevoRegalo()" class="btnAddRegalo">Añadir regalo</v-btn>
				</v-col>
			</v-row>
			<v-row>
				<!-- Regalo -->
				<v-col cols="12" v-for="(regalo, index) in rec.regalos" :key="index" align="center">
					<v-container style="padding: 0; margin: 0px;" align="center">
						<v-col align="center">
							<v-row align="center" style="margin-top: 1px;">
								<NuevoRegalo @change="recalcular()" :nuevoRegalo="regalo" v-bind:cantidadTotal="cantidadTotalR" style="width: 90%; margin-right: 5px;"></NuevoRegalo>
								<v-btn icon="mdi-delete-circle" density="compact" flat="true" @click="borrarRegalo(index)"></v-btn>
							</v-row>
						</v-col>
					</v-container>
				</v-col>
			</v-row>
			<v-row>
				<v-divider style="width: 100%; padding: 0px; margin-bottom: 8px;" :thickness="2" color="#000"></v-divider>
			</v-row>
			<v-row align="center" style="padding: 0px; width: 90%;">

				<!-- Total -->
				<v-row class="textTotal">
					<v-col align="center">
						<p><strong>TOTAL&nbsp;&nbsp;&nbsp;</strong> <span style="color: green;">{{rec.recaudacion.cantidadTotal}}€</span></p>
					</v-col>
				</v-row>
			</v-row>
			<v-row>
				<v-col>
					<v-btn type="submit" color="primary" class="btnEditarPerfil" v-on:click="editarRecaudacion()" prepend-icon="mdi-content-save">Editar recaudacion</v-btn>
				</v-col>
			</v-row>
			<v-row>
				<v-col>
					<v-btn type="submit" class="btnEditarPerfil" v-on:click="eliminarRecaudacion()" prepend-icon="mdi-delete-empty">Eliminar recaudacion</v-btn>
				</v-col>
			</v-row>
		</v-container>
		<!-- Mostrar mensaje cuando ocurra algun error -->
		<v-snackbar v-model="snackbar" :timeout="3000" style="margin-bottom: 100px; padding: 20px;" max-width="900px">
			<p style="color: white; font-size: 15px; padding: 0px;"> <v-icon icon="mdi-alert-octagon-outline" style="margin-right: 8px;"></v-icon>{{ snackbarText }}</p>
		</v-snackbar>
	</div>
</template>


<style>
	.btnAddRegalo
	{
		margin-top: 0px;
		margin-bottom: 25px;
		border: solid 2px #AF091D;
		color: #AF091D;

	}

	.textTotal
	{
		font-size: 16px;
		color: black;
	}
</style>

