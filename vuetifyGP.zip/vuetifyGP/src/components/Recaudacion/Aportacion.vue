<script setup>
	const props = defineProps({ aportacion: Object})
</script>

<template>
  <v-container style="border-radius: 5px; width: 100%; margin-top: 7px; margin-bottom: 7px; background-color: lightgray; ">
    <v-row align="center">
      <v-col cols="2" style="padding: 0px;" align="left">
        <v-img style="border-radius: 50%; width: 70%;" src="@/assets/LogoAportacion.png"></v-img>
      </v-col>
      <v-col cols="10" style="padding: 0px;" align="left">
		  <p style="font-size: 16px;"><strong>{{aportacion.username}}</strong> ha aportado <strong>{{aportacion.cantidadAportada}}€ </strong></p>
		  <p style="font-size: 16px;">a <strong>{{aportacion.regalo}} </strong></p>
      </v-col>
    </v-row>
  </v-container>
</template>

