Es<script setup>
	import {defineProps, computed, ref, onMounted} from 'vue';
	import store from "@/store";
	const props = defineProps({
		valor: Number,
		item: Object,
		tipo: Boolean,    //0 = recaudacion, 1 = aportacion
		tipoRec: Boolean  //0 = privada, 1 = publica
	})
	const usuarioLogeado = ref(computed(() => store.state.usuarioLogeado))
	let fecha = new Date(props.item.fechaFin);
	let opciones = { year: 'numeric', month: '2-digit', day: '2-digit' };
	let fechaFormateada = fecha.toLocaleDateString('es-ES', opciones);
	const porcentaje = computed(() => props.item.cantidadActual / props.item.cantidadTotal * 100);
	let usuario = ref(null)
	let color = ref("white")


	//Autenticacion del usuario
	onMounted(async () =>
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/user", {
				headers: { "Content-Type": "application/json" },
				credentials: "include"
			})
			if (response.status != 401) {
				usuario.value = await response.json()                     //Datos del usuario almacenados en la variable local de usuario
			}
		} catch (e) {console.log(e.message);await store.dispatch("setAuth", false); router.push('/NetworkError');}
		//Si la recaudacion no es del usuario logueado, marco blanco
		if(props.item.userId !== usuarioLogeado.value._id)
		{
			color.value = "white";
		}
		//Si la recaudacion es del usuario logueado, marco rojo, amarillo o verde en funcion del estado de la recaudacion
		else
		{
			if (props.item.estado === 'aceptada') {color.value = "#97d192";}
			else if (props.item.estado === 'denegada') color.value = "#e64343";
			else color.value = "#fff959";
		}
	})
</script>

<template>
	<v-card style="margin-bottom:10px; width: 100%; background-color: white; border: solid 5px;" :style="{ 'border-color': color }" elevation="2" class="carta">
    	<v-container style="width: 100%;">
        	<v-row align="center">
          		<v-col cols="4" style="padding: 0; padding-left: 10px;">
						<!--Imagen-->
						<v-img v-if="!tipo" width="100%" heigth="auto" :src="item.imagen"></v-img>
						<v-img v-if="tipo && item.recaudacion" width="100%" heigth="auto" :src="item.recaudacion.imagen"></v-img>
						<v-img v-if="tipo && !item.recaudacion" width="60%" heigth="auto" src="@/assets/LogoAportacion.png"></v-img>
          		</v-col>
				<v-col cols="8" align="center"  style="margin-bottom: 0px; padding-left: 0; padding-right: 0;" >
						<!--Estado-->
					<p v-if="usuario && item.userId == usuario._id && !tipo"><em>{{item.estado}}</em></p>
						<p v-if="tipo && usuario && item.recaudacion && item.recaudacion.userId == usuario._id">{{item.recaudacion.estado}}</p>
						<!--Nombre-->
						<strong><p v-if="!tipo">{{item.nombre}}</p></strong>
						<strong><p v-if="tipo && item.recaudacion">{{item.recaudacion.nombre}}</p></strong>
						<p style="font-size: 11px;" v-if="tipo && !item.recaudacion"><em>Recaudacion eliminada por el creador</em></p>
						<!--Fecha-->
						<p v-if="!tipo">Termina el {{fechaFormateada}}</p>
						<!--Info dinero-->
						<p v-if="!tipo">Recaudados <strong>{{item.cantidadActual}}€</strong> de <strong>{{item.cantidadTotal}}€</strong></p>
						<p v-if="tipo"><em>Aportaste: <strong>{{item.aportacion.cantidadAportada}}€</strong></em></p>
				</v-col>
        	</v-row>
			<v-row>
			  <!--Barra-->
			  <v-col cols="12" align="center" style="margin-bottom: 5px; padding: 0px; padding-left: 10px; padding-right: 10px;" v-if="!tipo">
				<v-progress-linear v-model="porcentaje" height="20" color="green">
				  <strong>{{Math.ceil(porcentaje)}}%</strong>
				</v-progress-linear>
			  </v-col>
			</v-row>
      	</v-container>
    </v-card>
</template>


