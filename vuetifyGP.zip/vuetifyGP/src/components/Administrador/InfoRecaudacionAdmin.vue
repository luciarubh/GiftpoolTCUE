<script setup>
	import {onMounted, ref, computed, defineProps} from "vue"
	import { useStore } from "vuex"
	import { useRouter } from 'vue-router'
	import LoginFail from "@/components/Login/LoginFail.vue";

	const store = useStore()
	const router = useRouter()
	const auth = computed(() => store.state.authenticated)
	let usuario = ref(null)
	//
	let rec = ref(null)
	const props = defineProps({
		id: Object
	})

	//Comprobar que el usuario está logeado y sea el usuario Administrador
	onMounted(async () =>
	{
		try {
			const response = await fetch("http://localhost:8000/api/user", {
				headers: {"Content-Type": "application/json"},
				credentials: "include"
			})
			if (response.status != 401)
			{
				if (response.status == 202)
				{
					usuario.value = await response.json()
					await store.dispatch("setAuth", true)
					store.dispatch('setUsuarioLogeado', usuario.value)
				}
				else
				{
					router.push("/");
				}
			}
		} catch (e) { await store.dispatch("setAuth", false) }
		//Datos de la recaudacion
		try
		{
			const id = props.id;
			const resp = await fetch(`http://localhost:8000/api/recaudacion/${id}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
				},
			}).then(response => response.json())
				.then(data => {rec.value = data; })
				.catch((error) => { console.error('Error:', error); });
		} catch (e) {console.log(e.message)}
	})

	//Click en boton aceptar recaudacion. Enviar peticion al servidor
	const aceptarRecaudacion = () => {
		try {
			fetch('http://localhost:8000/api/aceptarPeticionRecadacion', {
				method: 'POST',
				headers: {'Content-Type': 'application/json',},
				credentials: 'include',
				body: JSON.stringify({ id: rec.value.recaudacion._id })
			}).then(response => {});
			router.push("/homeAdmin");
		}catch (e) {console.log(e.message)}
	}
	//Click en boton denegar recaudacion. Redirigir a la página de motivo de denegacion
	const denegarRecaudacion= () => {
		router.push({ name: 'motivo', params: { id: rec.value.recaudacion._id } });
	}
</script>


<template>
	<!--LOGIN INCORRECTO-->
	<p class="pAuthFail" align="center" v-if="!auth">
		<LoginFail></LoginFail>
	</p>
	<!--LOGIN CORRECTO-->
	<v-main style="--v-layout-top: 0px; padding: 10px;" width="100%;" v-if="auth && rec">
		<v-container  style="width: 100%; margin: 0px;">
			<v-row align="center" style="padding: 0px;">
				<v-col align="center" style="padding: 0px;">
					<p align="center" style=" background-color: #AF091D ; color: white; font-size: 20px; border-radius: 5px; margin-bottom: 5px;">
						Información de recaudación
					</p>
				</v-col>
			</v-row>
			<v-row>
				<p><strong>Banner: </strong>
					<div style="border: solid 1px lightgrey;" ><span v-if="rec.recaudacion" v-html="rec.recaudacion.vquill" style="padding: 0px; margin-bottom: 10px;"></span></div>
				</p>
			</v-row>
			<v-row>
				<p><strong>Nombre: </strong>{{rec.recaudacion.nombre}}</p>
			</v-row>
			<v-row>
				<p><strong>Descripcion: </strong>{{rec.recaudacion.descripcion}}</p>
			</v-row>
			<v-row>
				<p><strong>Fecha fin: </strong>{{rec.recaudacion.fechaFin}}</p>
			</v-row>
			<v-row>
				<p><strong>Cantidad total: </strong>{{rec.recaudacion.cantidadTotal}}</p>
			</v-row>
			<v-row>
				<p><strong>Tipo: </strong>{{rec.recaudacion.tipoRecaudacion}}</p>
			</v-row>
			<v-row>
				<p><strong>Imagen de la portada: </strong>
					<img :src="rec.recaudacion.imagen" align="center" style="width: 50px;"></p>
			</v-row>
			<v-row align="center">
				<p><strong>REGALOS: </strong></p>
			</v-row>
			<v-row v-if="rec.regalos" v-for="regalo in rec.regalos" >
				<p>{{regalo.nombre}} - {{regalo.cantidad}} - {{regalo.precioUnidad}}</p> - {{regalo.precioTotal}}
			</v-row>

			<v-row align="center" v-if="rec.recaudacion.estado == 'pendiente'">
				<v-col align="center">
					<v-btn @click="() => aceptarRecaudacion()" style="background-color: green; color: white; font-weight: bold;  font-size: 14px; padding: 10px; height: auto; margin-bottom: 10px; margin-top: 10px;">Aceptar recaudación</v-btn>
					<v-btn @click="() => denegarRecaudacion(rec.recaudacion._id)" style="background-color: red; color: white; font-weight: bold;  font-size: 14px; padding: 10px; height: auto; margin-bottom: 5px;">Denegar recaudación</v-btn>
				</v-col>
			</v-row>
		</v-container>
	</v-main>
</template>



