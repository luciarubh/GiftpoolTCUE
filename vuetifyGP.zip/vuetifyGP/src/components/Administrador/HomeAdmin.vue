<script setup>
	import { ref, onMounted, computed } from 'vue'
	import { useStore } from 'vuex'
	import {useRouter} from "vue-router";
	import LoginFail from "@/components/Login/LoginFail.vue";

	const router = useRouter();
	const store = useStore()
	const auth = computed(() => store.state.authenticated)
	let usuario = ref(null)
	let userLog = ref(computed(() => store.state.usuarioLogeado))
	//
	let listaPendientes = ref(null)
	let listaAceptadas = ref(null)
	let listaDenegadas = ref(null)
	let listaValoraciones = ref(null)
	let media = ref (0)

	//Comprobar que el usuario está logeado y sea el usuario Administrador
	onMounted(async () =>
	{
		try
		{
			const response = await fetch("http://localhost:8000/api/user", {
				headers: { "Content-Type": "application/json" },
				credentials: "include"
			})
			//Si el usuario está logueado, comprobar si es el Administrador
			if (response.status != 401)
			{
				if (response.status == 202)
				{
					//Usuario administrador
					usuario.value = await response.json()
					await store.dispatch("setAuth", true)
					store.dispatch('setUsuarioLogeado', usuario.value)
				}
				else
				{
					//Usuario NO administrador
					router.push("/");
				}
			}
		} catch (e) { await store.dispatch("setAuth", false) }

		//Cargar listas de recaudaciones pendientes, aceptadas y denegadas para la visualizacion del administrador
		const res = await fetch("http://localhost:8000/api/recaudacionesAdmin", {
			headers: { "Content-Type": "application/json" },
			credentials: "include"
		})
			.then(response => response.json())
			.then(data =>
			{
				listaPendientes = data.listaPendientes;
				listaAceptadas = data.listaAceptadas;
				listaDenegadas = data.listaDenegadas;
			}).catch(error => console.log("Error:", error));

		//Cargar lista de valoraciones y calcular la media obtenida
		const resVal = await fetch("http://localhost:8000/api/valoracionesAdmin", {
			headers: { "Content-Type": "application/json" },
			credentials: "include"
		})
			.then(response => response.json())
			.then(data =>
			{
				listaValoraciones = data.message;
				let suma = 0;
				for (let i = 0; i < listaValoraciones.length; i++) {
					suma += listaValoraciones[i].rating;
				}
				media.value = suma / listaValoraciones.length;
			}).catch(error => console.log("Error:", error));
	})//Fin OnMounted()

	//Si selecciona una recaudacion de una de las listas, redirigir a la vista de la recaudacion seleccionada
	const verRecaudacion = (recaudacion) =>
	{
		let recSeleccionada = recaudacion
		router.push({name: 'recaudacionAdmin', params: { id: recSeleccionada._id } });
	}

	//Si selecciona una valoracion de la lista, redirigir a la vista de la valoracion seleccionada
	const verValoracion= (valoracion) =>
	{
		let valSeleccionada = valoracion
		router.push({name: 'valoracionAdmin', params: { id: valoracion._id } });
	}
</script>

<template>
  <!--LOGIN INCORRECTO-->
  <p class="pAuthFail" align="center" v-if="!auth">
    <LoginFail></LoginFail>
  </p>
  <!--LOGIN CORRECTO-->
  <v-main style="--v-layout-top: 0px;" width="100%;" v-if="auth">
	  <v-container  style="width: 95%; margin: 0px;">
		  <v-row align="center">
			  <v-col align="center">
<!--	  				<p><strong>PERFIL DEL ADMIN</strong></p>-->
				  <p align="center" style=" background-color: #AF091D ; color: white; font-size: 20px; border-radius: 5px;">
					  PERFIL DEL ADMINISTRADOR
				  </p>
			  </v-col>
		  </v-row>
		  <v-row align="center" style="margin-top: 5px; padding: 0;">
			  <v-col align="center">
				  <p><strong>RECAUDACIONES</strong></p>
			  </v-col>
		  </v-row>
		  <v-row align="center" style="margin: 0px; margin-top: 15px; padding: 0;">
			  <v-col align="center" style="margin: 0px; padding: 0;">
				  <v-expansion-panels >
					  <v-expansion-panel>
						  <!--Titulos-->
						  <v-expansion-panel-title disable-icon-rotate>
							  PENDIENTES
							  <template v-slot:actions>
								  <v-icon color="warning" icon="mdi-clock">
								  </v-icon>
							  </template>
						  </v-expansion-panel-title>
						  <!--Contenido-->
						  <v-expansion-panel-text v-for="recaudacion in listaPendientes" @click="() => verRecaudacion(recaudacion)">
							  <v-container style="border: 1px solid white; padding: 0; margin: 0px;">
								  <v-row align="center" style="padding: 0; margin: 0px;">
										<v-col align="center" cols="2" style="padding: 0; margin: 0px;" >
								  			<img :src="recaudacion.imagen" align="center" style="width: 50px;">
									  	</v-col>
									  	<v-col align="center" style="padding: 0; margin: 0px;">
								  			{{ recaudacion.nombre }}
										</v-col>
								  </v-row>
							  </v-container>
						  </v-expansion-panel-text>
					  </v-expansion-panel>
				  </v-expansion-panels>
			  </v-col>
		  </v-row>
		  <v-row style="margin: 0px; padding: 0; margin-top: 10px;">
			  <v-col align="center" style="margin: 0px; padding: 0;">
				  <v-expansion-panels>
					  <v-expansion-panel>
						  <v-expansion-panel-title disable-icon-rotate>
							  ACEPTADAS
							  <template v-slot:actions>
								  <v-icon color="success" icon="mdi-check-bold">
								  </v-icon>
							  </template>
						  </v-expansion-panel-title>
						  <v-expansion-panel-text v-for="recaudacion in listaAceptadas" @click="() => verRecaudacion(recaudacion)">
							  <v-container style="border: 1px solid white; padding: 0; margin: 0px;">
								  <v-row align="center" style="padding: 0; margin: 0px;">
									  <v-col align="center" cols="2" style="padding: 0; margin: 0px;" >
										  <img :src="recaudacion.imagen" align="center" style="width: 50px;">
									  </v-col>
									  <v-col align="center" style="padding: 0; margin: 0px;">
										  {{ recaudacion.nombre }}
									  </v-col>
								  </v-row>
							  </v-container>
						  </v-expansion-panel-text>
					  </v-expansion-panel>
				  </v-expansion-panels>
			  </v-col>
		  </v-row>
		  <v-row style="margin: 0px; padding: 0; margin-top: 10px;">
			  <v-col align="center" style="margin: 0px; padding: 0;">
				  <v-expansion-panels>
				  <v-expansion-panel>
					  <v-expansion-panel-title disable-icon-rotate>
						  DENEGADAS
						  <template v-slot:actions>
							  <v-icon color="error" icon="mdi-close-thick">
							  </v-icon>
						  </template>
					  </v-expansion-panel-title>
					  <v-expansion-panel-text v-for="recaudacion in listaDenegadas" @click="() => verRecaudacion(recaudacion)">
						  <v-container style="border: 1px solid white; padding: 0; margin: 0px;">
							  <v-row align="center" style="padding: 0; margin: 0px;">
								  <v-col align="center" cols="2" style="padding: 0; margin: 0px;" >
									  <img :src="recaudacion.imagen" align="center" style="width: 50px;">
								  </v-col>
								  <v-col align="center" style="padding: 0; margin: 0px;">
									  {{ recaudacion.nombre }}
								  </v-col>
							  </v-row>
						  </v-container>
					  </v-expansion-panel-text>
				  </v-expansion-panel>
				  </v-expansion-panels>
				  <v-row align="center" style="margin-top: 10px;">
					  <v-col align="center">
						  <p><strong>OTROS</strong></p>
					  </v-col>
				  </v-row>
				  <!--VALORACIONES-->
				  <v-expansion-panels style="margin-top: 10px;">
					  <v-expansion-panel>
						  <!--Titulos-->
						  <v-expansion-panel-title disable-icon-rotate>
							  VALORACIONES
							  <span v-if="!media"><em> (Media: 0)</em> </span>
							  <span v-if="media"><em> (Media: {{ media }})</em> </span>
							  <template v-slot:actions>
								  <v-icon color="orange-lighten-1" icon="mdi-star">
								  </v-icon>
							  </template>
						  </v-expansion-panel-title>
						  <!--Contenido-->
						  <v-expansion-panel-text v-for="valoracion in listaValoraciones" @click="() => verValoracion(valoracion)">
							  <v-container style="border: 1px solid white; padding: 0; margin: 0px; border: solid 1px lightgrey; border-radius: 5px;">
								  <v-row v-if="valoracion.vista == true" align="center" style="padding: 0; margin: 0px; ">
									  <v-col align="center" style="padding: 0; margin: 0px;">
										  <span style="font-style: italic; text-transform: none;">
											  <span class="mdi mdi-eye-check"></span>
											  <strong>Vista</strong>
										  </span>
									  </v-col>
								  </v-row>
								  <v-row align="center" style="padding: 0; margin: 0px; ">
									  <v-col align="center" style="padding: 0; margin: 0px;">
										  <span style="font-style: italic;">{{ valoracion.username }}</span>
									  </v-col>
								  </v-row>
								  <v-row align="center" style="padding: 0; margin: 0px; ">
									  <v-col align="center" style="padding: 0; margin: 0px;">
										  <span style="font-style: italic;">{{ valoracion.fecha }}</span>
									  </v-col>
								  </v-row>
								  <v-row align="center" style="padding: 0; margin: 0px; ">
										<v-col align="center" style="padding: 0; margin: 0px;">
											<v-rating readonly size="x-small" v-model="valoracion.rating" active-color="green" color="green" ></v-rating>
									  	</v-col>
								  </v-row>
							  </v-container>
						  </v-expansion-panel-text>
					  </v-expansion-panel>
				  </v-expansion-panels>

				  <!--PAGOS-->
				  <v-expansion-panels style="margin-top: 10px;">
					  <v-expansion-panel >
						  <!--Titulos-->
						  <v-expansion-panel-title disable-icon-rotate>
							  SOLICITUDES DE PAGO
							  <template v-slot:actions>
								  <v-icon color="blue" icon="mdi-currency-eur">
								  </v-icon>
							  </template>
						  </v-expansion-panel-title>
						  <!--Contenido-->
						  <v-expansion-panel-text>
							  Estás al día con las solicitudes de pago.
						  </v-expansion-panel-text>
					  </v-expansion-panel>
				  </v-expansion-panels>
			  </v-col>
		  </v-row>
	  </v-container>
  </v-main>
</template>

<style>
  .tabs
  {
    font-size: 12px;
    width: 50%;
    text-transform: none;
  }
</style>
