<script setup>
	import {onMounted, ref, computed, defineProps} from "vue"
	import { useStore } from "vuex"
	import { useRouter } from 'vue-router'
	import LoginFail from "@/components/Login/LoginFail.vue";
	import { format } from 'date-fns'

	const store = useStore()
	const router = useRouter()
	let usuario = ref(null)
	const auth = computed(() => store.state.authenticated)
	//
	let val = ref(null)
	let fecha = ref(null)
	const props = defineProps({
		id: Object
	})

	onMounted(async () =>
	{
		try
		{
			//Comprobar que el usuario está logeado y sea el usuario Administrador
			const response = await fetch("http://localhost:8000/api/user", {
				headers: {"Content-Type": "application/json"},
				credentials: "include"
			})
			if (response.status != 401)
			{
				if (response.status == 202)
				{
					usuario.value = await response.json()
					await store.dispatch("setAuth", true)
					store.dispatch('setUsuarioLogeado', usuario.value)
				}
				else
				{
					router.push("/");
				}
			}
		} catch (e) {await store.dispatch("setAuth", false)}
		//Obtener datos de la valoracion
		try
		{
			const id = props.id;
			const resp = await fetch(`http://localhost:8000/api/valoracion/${id}`, {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
				},
			}).then(response => response.json())
				.then(data =>
				{
					val.value = data;
					fecha = new Date(val.value.valoracion.fecha);
					let opciones = { year: 'numeric', month: '2-digit', day: '2-digit' };
					fecha.value = fecha.toLocaleDateString('es-ES', opciones);
				});
		} catch (e) {console.log(e.message)}
	})

	//Funcion para formatear fecha tipo Date a formato: Dia-Mes-Año
	const fechaFormateada = computed(() => {
		if (val.value.valoracion.fecha) {
			const fecha = new Date(val.value.valoracion.fecha);
			const dia = String(fecha.getDate()).padStart(2, '0');
			const mes = String(fecha.getMonth() + 1).padStart(2, '0'); // Los meses empiezan desde 0
			const anio = fecha.getFullYear();
			return `${dia}-${mes}-${anio}`;
		}
		return '';
	})

	//Volver a la pagina de perfil de administrador
	async function volver()
	{
		router.go(-1);
	}

	//Marcar valoracion como leida
	async function borrarValoracion()
	{
		const resp = await fetch(`http://localhost:8000/api/borrarValoracion`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(val.value.valoracion)
		}).then(response => console.log(response)).then(router.push('/homeAdmin'));
	}
</script>

<template>
	<!--LOGIN INCORRECTO-->
	<p class="pAuthFail" align="center" v-if="!auth">
		<LoginFail></LoginFail>
	</p>
	<!--LOGIN CORRECTO-->
	<div class="text-center" v-if="val && auth">
		<v-container style="padding: 0; margin-top: 20px;">
			<!--Titulo-->
			<v-row align="center" style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<p class="pregunta" style="margin: 0px; padding: 0;">VALORACIÓN RECIBIDA</p>
				</v-col>
			</v-row>
			<!--Fecha-->
			<v-row style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<p v-if="val.valoracion.fecha">Fecha: {{fechaFormateada}}</p>
				</v-col>
			</v-row>
			<!--Estrellas-->
			<v-row align="center" style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<v-rating readonly v-model="val.valoracion.rating" active-color="orange-lighten-1" color="orange-lighten-1" style="margin: 0px; padding: 0;" ></v-rating>
				</v-col>
			</v-row>
			<!--Positivo-->
			<v-row style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<v-textarea readonly v-model="val.valoracion.positivo" prepend-inner-icon="mdi-check-decagram-outline" label="Aspectos positivos" variant="outlined" style="margin-left: 20px; margin-right: 20px;" rows="5"></v-textarea>
				</v-col>
			</v-row>
			<!--Negativo-->
			<v-row style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<v-textarea readonly v-model="val.valoracion.negativo" prepend-inner-icon="mdi-alert-decagram" label="Aspectos negativos" variant="outlined" style="margin-left: 20px; margin-right: 20px;" rows="5"></v-textarea>
				</v-col>
			</v-row>
			<!--Boton eliminar-->
			<v-row style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<v-btn @click="borrarValoracion()" style="background-color: green; color: white; margin-top: 0px;" v-on:click="guardar" prepend-icon="mdi-eye-check-outline">Marcar como leída</v-btn>
				</v-col>
			</v-row>
			<!--Boton volver-->
			<v-row style="padding: 0; margin: 0px;">
				<v-col style="padding: 0; margin: 0px;">
					<v-btn @click="volver()" prepend-icon="mdi-arrow-left-circle-outline" style="background-color: #00457C; color: white; font-weight: bold;  font-size: 14px; padding: 10px; height: auto; margin-top: 10px;">Volver</v-btn>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<style scoped>
	.pregunta
	{
		font-size: 20px;
		font-weight: bold;
		margin: 20px;
	}
</style>
