<script setup>
	import {computed, defineProps, onMounted, ref} from 'vue'
	import { useStore } from 'vuex'
	import {useRouter} from "vue-router";
	import LoginFail from "@/components/Login/LoginFail.vue";

	const auth = computed(() => store.state.authenticated)
	const router = useRouter();
	const store = useStore()
	//
	let motivo = ref("")
	const props = defineProps({
		id: Object
	})

	//Comprobar que el usuario está logeado y sea el usuario Administrador
	onMounted(async () =>
	{
		try {
			const response = await fetch("http://localhost:8000/api/user", {
				headers: {"Content-Type": "application/json"},
				credentials: "include"
			})

			if (response.status != 401) {
				if (response.status == 202) {
					usuario.value = await response.json()
					await store.dispatch("setAuth", true)
					store.dispatch('setUsuarioLogeado', usuario.value)
				} else {
					router.push("/");
				}
			}
		} catch (e) {console.log(e); }
	})

	//Enviar denegacion de la recaudacion al servidor, incluyendo el motivo por el cual se ha denegado
	const denegarRecaudacion = () => {
		try {
			fetch('http://localhost:8000/api/denegarPeticionRecaudacion', {
				method: 'POST',
				headers: {'Content-Type': 'application/json',},
				credentials: 'include',
				body: JSON.stringify({ id: props.id, motivo: motivo.value })
			}).then(response => {});
			router.push("/homeAdmin");		//Redigir al perfil de administrador
		}catch (e) {console.log(e.message)}
	}
</script>


<template>
	<!--LOGIN INCORRECTO-->
	<p class="pAuthFail" align="center" v-if="!auth">
		<LoginFail></LoginFail>
	</p>
	<!--LOGIN CORRECTO-->
	<div v-if="auth">
		<v-container style="margin:0px; padding: 0px;">
			<v-col style="margin:0px; padding:0;" align="center">
				<p class="pregunta">¿Cúal es el motivo de la denegación de la recaudacion?</p>
			</v-col >
			<v-col style="margin:0px; padding:0;" align="center">
				<v-textarea variant="outlined" style="margin: 20px;" v-model="motivo" rows="13"></v-textarea>
			</v-col>
			<v-col style="margin:0px; padding: 0;" align="center">
				<v-btn @click="() => denegarRecaudacion()" style="background-color: red; color: white; font-weight: bold;  font-size: 14px; padding: 10px; height: auto; margin-bottom: 15px; ">Enviar motivo</v-btn>
			</v-col>
		</v-container>
	</div>
</template>

<style scoped>
.pregunta
{
	font-size: 20px;
	font-weight: bold;
	margin: 20px;
}
</style>
