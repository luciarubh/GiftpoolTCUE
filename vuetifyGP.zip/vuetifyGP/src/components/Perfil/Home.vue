usua<script setup>
	import { ref, onMounted, computed } from 'vue'
	import { useStore } from 'vuex'
	import {useRouter} from "vue-router";

	const router = useRouter();
	const store = useStore()
	const auth = computed(() => store.state.authenticated)
	const valorRec = ref(75)
	const valorApor = ref(0)
	const tab = ref(null)
	let usuario = ref(null)

	onMounted(async () =>
	{
		try {
			const response = await fetch("http://localhost:8000/api/user", {
				headers: { "Content-Type": "application/json" },
				credentials: "include"
			})
			if (response.status != 401) {
				usuario.value = await response.json()                     //Datos del usuario almacenados en la variable local de usuario
				await store.dispatch("setAuth", true)
				store.dispatch('setUsuarioLogeado', usuario.value)   //Asignar a la variable global de usuario la variable local
				if (usuario.value.username === "admin") router.push("/homeAdmin");
			}
		} catch (e) {
			await store.dispatch("setAuth", false)
		}
	})
</script>


<template>
	<!--LOGIN INCORRECTO-->
  	<p class="pAuthFail" align="center" v-if="!auth">
    	<LoginFail></LoginFail>
  	</p>
	<!--LOGIN CORRECTO-->
	<v-main style="--v-layout-top: 0px;  border: none;" width="100%" v-if="auth">
		<Banner></Banner>
		<!--TABS: Recaudaciones y participaciones-->
		<v-card elevation="0" style="margin-top: 10px;">
			<v-tabs v-model="tab" color="#AF091D" align-tabs="center">
				<v-tab class="tabs" value="1">Mis recaudaciones</v-tab>
				<v-tab class="tabs" value="2">Mis participaciones</v-tab>
		  	</v-tabs>
			<v-card-text>
			<!--RECAUDACIONES-->
			<v-window v-model="tab">
				<v-window-item value="1">
					<!--Recaudaciones en curso-->
					<ListaRecaudaciones v-bind:valor="valorRec" v-bind:tipo="false" v-bind:tipoRec="true"></ListaRecaudaciones>
				</v-window-item>
				<!--PARTICIPACIONES-->
				<v-window-item value="2">
					<ListaRecaudaciones v-bind:valor="valorApor" v-bind:tipo="true" v-bind:tipoRec="false"></ListaRecaudaciones>
				</v-window-item>
			</v-window>
			</v-card-text>
		</v-card>
	</v-main>
</template>




<style>
  .tabs
  {
    font-size: 12px;
    width: 50%;
    text-transform: none;
  }
</style>
