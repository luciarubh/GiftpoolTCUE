<script setup>
	import { onMounted, ref} from "vue"
	import { useRouter } from 'vue-router'
	import PrevisualizacionRecaudacion from "@/components/Recaudacion/PrevisualizacionRecaudacion.vue";

	const router = useRouter()
	const props = defineProps({ valor: Number, tipo: Boolean, tipoRec: Boolean})
	const dialog = false;
	var ListaRecaudaciones = ref([]);
	var ListaAportaciones = ref([]);
	var RecaudacionesAportaciones = ref([]);
	let recSeleccionada = ref(null)
	let listaDatosAportaciones = ref ([])
	let listaTerminadas = ref([])
	let listaActuales = ref([])

	onMounted(async () =>
	{
		//RECAUDACIONES DEL USUARIO
		try
		{
			const response = await fetch("http://localhost:8000/api/recaudacionesUser",
			{
				headers: { "Content-Type": "application/json" },
				credentials: "include",
			})
			const resp = await response.json();
			ListaRecaudaciones.value = resp.message
			//Comprobar si la recaudacion esta en curso o ya ha terminado
			ListaRecaudaciones.value.forEach(recaudacion => {
				let fechaRecaudacion = new Date(recaudacion.fechaFin);
				let hoy = new Date();

				// Establecer las horas, minutos, segundos y milisegundos a 0 para comparar solo la fecha
				fechaRecaudacion.setHours(0, 0, 0, 0);
				hoy.setHours(0, 0, 0, 0);

				if (recaudacion.terminada == true) {
					listaTerminadas.value.push(recaudacion);
				} else {
					listaActuales.value.push(recaudacion);
				}
			});
		} catch (e) {console.log("Algo ha ido mal")}

		//APORTACIONES DE USUARIO
		try
		{
			const response = await fetch("http://localhost:8000/api/aportacionesUser",
			{
				headers: { "Content-Type": "application/json" },
			  	credentials: "include",
			})
		  	const resp = await response.json();
		  	ListaAportaciones.value = resp.message;
			//Lista de recaudaciones asociadas a las aportaciones
			for (let i = 0; i < ListaAportaciones.value.length; i++)
			{
				const response = await fetch("http://localhost:8000/api/recaudacion/" + ListaAportaciones.value[i].recaudacionId,
				{
					headers: { "Content-Type": "application/json" },
					credentials: "include",
				})
				const resp = await response.json();
				let datosAportacion =
				{
						recaudacion: resp.recaudacion,
						aportacion: ListaAportaciones.value[i]
				};
				listaDatosAportaciones.value.push(datosAportacion);
			}
		} catch (e) {console.log("Algo ha ido mal")}
	})

	//Al hacer click en una recaudacion
	const handleClick = (item) => {
		recSeleccionada.value = item
		router.push({name: 'recaudacion', params: { id: recSeleccionada.value._id } });
	}

</script>

<template>
	<!--CREAR NUEVA RECAUDACION-->
	<v-container v-if="!tipo"  style="padding: 15px; margin-bottom: 0px;">
		<v-row align="center">
			<v-col align="center" style="padding: 0px; margin: 0px;">
				<v-dialog v-model="dialog" max-width="40vw" persistent>
					<template v-slot:activator="{ props: activatorProps }">
						<router-link to="/crearRecaudacion" class="text-decoration-none">
							<v-btn v-bind="activatorProps" color="green" class="btnAñadirRecaudacion">Crear nueva recaudacion</v-btn>
						</router-link>
					</template>
				</v-dialog>
			</v-col>
		</v-row>
		<!--RECAUDACIONES TERMINADAS-->
		<v-row>
			<v-col align="center" style="padding: 0px; margin-top: 10px;">
				<v-expansion-panels style="width: 95%;" >
					<v-expansion-panel>
						<v-expansion-panel-title disable-icon-rotate>
							<strong>FINALIZADAS</strong>
							<template v-slot:actions>
								<v-icon color="error" icon="mdi-clock-remove">
								</v-icon>
							</template>
						</v-expansion-panel-title>
						<v-expansion-panel-text>
							<v-container style="border: 1px solid white; padding: 0; margin: 0px;">
								<v-row align="center" style="padding: 0; margin: 0px;">
									<PrevisualizacionRecaudacion v-if="!tipo & listaTerminadas.length > 0" style="width: 100%; height: 10%;" v-for="item in listaTerminadas" @click="() => handleClick(item)"  align="center" v-bind:item="item" v-bind:tipo="props.tipo" v-bind:tipoRec="props.tipoRec"></PrevisualizacionRecaudacion>
									<p v-if="!tipo & listaTerminadas.length <= 0">Todavia no ha finalizado ninguna recaudacion</p>
								</v-row>
							</v-container>
						</v-expansion-panel-text>
					</v-expansion-panel>
				</v-expansion-panels>
			</v-col>
		</v-row>
	</v-container>

	<v-container style="padding: 0px; margin-top: 0px;">
		<v-col align="center">
			<!--Recaudaciones-->
			<PrevisualizacionRecaudacion v-if="!tipo & listaActuales.length > 0" style="width: 100%; height: 10%;" v-for="item in listaActuales" @click="() => handleClick(item)"  align="center" v-bind:item="item" v-bind:tipo="props.tipo" v-bind:tipoRec="props.tipoRec"></PrevisualizacionRecaudacion>
			<p v-if="!tipo & listaActuales.length <= 0">Todavia no has publicado ninguna recaudacion</p>
			<!--Aportaciones-->
			<PrevisualizacionRecaudacion v-if="tipo & ListaAportaciones.length > 0" style="width: 100%; height: 10%;" v-for="item in listaDatosAportaciones" align="center" v-bind:item="item" v-bind:tipo="props.tipo" v-bind:tipoRec="props.tipoRec"></PrevisualizacionRecaudacion>
			<p v-if="tipo & ListaAportaciones.length <= 0">Todavía no has participado en ninguna recaudación.</p>
	  	</v-col>
  	</v-container>
</template>




<style>
  .cardRecaudacion
  {
    border:solid;
    border-color: #AF091D;
    border-width: 3px;
    border-radius: 8px;
  }
  .marcar{
    border: solid;
    border-color: green;
    border-width: 1px;
    border-radius: 8px;
  }
  .imagen
  {
    width: 90px;
    border: solid;
    border-color: gray;
    border-radius: 50%;
    border-width: 1px;
  }
  .info {
    align-content: center;
    font-size: 22px;

  }
  .btnA�adirRecaudacion {
    font-size: 12px;
    padding: 3px;
    padding-top: 0px;
    padding-bottom: 0px;
    text-transform: none;
  }
  .btnVerDetalles
  {
    border: solid;
    border-width: 3px;
    border-color: forestgreen;
    border-radius: 5px;
    text-transform: none;
    font-size: 20px;
  }
</style>




