usua<script setup>
import { ref, onMounted, computed } from 'vue'
import { useStore } from 'vuex'
import User from "@/models/user";
import LoginFail from "@/components/Login/LoginFail.vue";
import {useRouter} from "vue-router";

const router = useRouter();
const store = useStore()
const auth = store.state.authenticated
const showPassword = ref(false)
const password = ref("")
const passwordConf = ref("")
var snackbar = ref(false)
var snackbarText = ref("")
let usuario = ref(null)


onMounted(async () =>
{
	//Autenticacion del usuario
	try
	{
		const response = await fetch("http://localhost:8000/api/user", {
			headers: { "Content-Type": "application/json" },
			credentials: "include"
		})
		if (response.status != 401)
		{
			await store.dispatch("setAuth", true)
			usuario.value = await response.json()                     //Datos del usuario almacenados en la variable local de usuario
		}
	} catch (e) {console.log(e.message)}
})

async function guardar()
{
	if (password.value !== passwordConf.value)
	{
		snackbarText.value = "La contraseña no coincide"
		snackbar.value = true;
	}
	else
	{
		let userM = new User(usuario.value.username, usuario.value.email, password.value, usuario.value.nombreApellidos, usuario.value.vquill)
		const response = await fetch("http://localhost:8000/api/editarUsuario",
			{
				method: "POST",
				headers: { "Content-Type": "application/json", },
				credentials: 'include',
				body: JSON.stringify
				({
					user: userM,
				}),
			}).then( () => {
					store.dispatch('setUsuarioLogeado', userM.value);
					router.push('/Home');
				});//fin fetch

	}
}

async function eliminarCuenta()
{
	try
	{
		const response = await fetch("http://localhost:8000/api/eliminarUsuario",
		{
				method: "POST",
				headers: {"Content-Type": "application/json",},
				credentials: 'include',
				body: JSON.stringify
				({
					user: usuario.value,
				}),
		})
		if (response.status == 406)
		{
			snackbarText.value = "Termine todas sus recaudaciones para poder eliminar el perfil.";
			snackbar.value = true;
		}
		else
		{
			store.dispatch('setAuth', false);
			router.push('/');
		}
	}catch (e) { console.log(e.message)}
}
</script>

<template>
	<!--NO AUTORIZADO-->
	<p class="pAuthFail" align="center" v-if="!auth">
		<LoginFail></LoginFail>
	</p>
	<!--AUTORIZADO-->
	  <div style="border: none; width: 100%;" v-if="auth && usuario" >
		<v-form style="padding: 15px;">
		  <p align="center" style=" background-color: #AF091D ; color: white; font-size: 20px; border-radius: 5px; margin-bottom: 5px;">Editar perfil</p>
		  <!--QUILL-->
		  <p>Banner del perfil</p>
		  <quill-editor v-model:content="usuario.vquill" content-type="html" theme="snow" toolbar="full" style="margin-bottom: 10px;"></quill-editor>
		  <!-- Nombre -->
		  <v-text-field density="compact" variant="outlined" align="center" v-model="usuario.nombreApellidos">
			<template v-slot:prepend-inner>
			  <v-icon icon="mdi-rename-box" color="warning" />
			</template>
			<template v-slot:label>
			  <span style="font-size: 11px;">Nombre y Apellidos</span>
			</template>
		  </v-text-field>
		  <!--Usuario-->
		  <v-text-field density="compact" variant="outlined" align="center" v-model="usuario.username">
			<template v-slot:prepend-inner>
			  <v-icon icon="mdi-account" color="warning" />
			</template>
			<template v-slot:label>
			  <span style="font-size: 11px;">Nombre de usuario</span>
			</template>
		  </v-text-field>
		  <!--Email-->
		  <v-text-field density="compact" variant="outlined" align="center" v-model="usuario.email">
			<template v-slot:prepend-inner>
			  <v-icon icon="mdi-at" color="warning" />
			</template>
			<template v-slot:label>
			  <span style="font-size: 11px;">Email</span>
			</template>
		  </v-text-field>
		  <!--Contrase�a-->
		  <v-text-field v-model="password" :append-inner-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'" :type="showPassword ? 'text' : 'password'"
						density="compact" placeholder="Introduce la nueva contraseña" prepend-inner-icon="mdi-lock"
						variant="outlined" @click:append-inner="showPassword = !showPassword"></v-text-field>

		  <!--Confirmar contrase�a-->
		  <v-text-field v-model="passwordConf" :append-inner-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'" :type="showPassword ? 'text' : 'password'"
						density="compact" placeholder="Confirma la contraseña" prepend-inner-icon="mdi-lock"
						variant="outlined" @click:append-inner="showPassword = !showPassword"></v-text-field>
		  <!--GUARDAR-->
		  <v-col align="center" style="padding: 0px;;">
			<v-btn class="btnEditarPerfil" v-on:click="guardar" color="primary" prepend-icon="mdi-content-save">Guardar cambios</v-btn>
		  </v-col>
		  <v-col align="center" style="padding: 0px; margin-top: 15px;">
				<v-btn class="btnEditarPerfil" v-on:click="eliminarCuenta" color="#AF091D" prepend-icon="mdi-delete-empty">Eliminar cuenta</v-btn>
		  </v-col>
		</v-form>
		<v-snackbar v-model="snackbar" :timeout="1000" style="margin-bottom: 100px; padding: 20px;" max-width="900px">
		  <p style="color: white; font-size: 15px; padding: 0px;"> <v-icon icon="mdi-alert-octagon-outline" style="margin-right: 8px;"></v-icon>{{ snackbarText }}</p>
		</v-snackbar>
	  </div>
</template>





<style>
  .btnEditarPerfil {
    background-color: #AF091D;
    color: white;
    font-weight: bold;
    border-width: thin;
    font-size: 14px;
    padding: 5px;
    height: auto;
    padding: 10px;
  }

  .ql-align-center
  {
      text-align: center; }
</style>
