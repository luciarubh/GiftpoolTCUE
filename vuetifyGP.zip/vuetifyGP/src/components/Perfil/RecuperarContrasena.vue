inici<script setup>
	import {ref} from "vue";

	let email = ref("");
	let usuario = ref("");
	let snackbar = ref(false);
	let snackbarText = ref("");
	let snackbar2 = ref(false);
	let snackbarText2 = ref("");

	//Enviar el usuario y el email introducidos. Si coinciden con los datos de la base de datos, se enviará un correo con la nueva contraseña
	async function recuperarContrasena()
	{
		if (usuario.value === "" || email.value === "") {
			snackbarText2.value = "Los campos no pueden estar vacíos";
			snackbar2.value = true;
		}
		else
		{
			try
			{
				const response = await fetch("http://localhost:8000/api/recuperarContrasena",
					{
						method: 'POST',
						headers: {"Content-Type": "application/json"},
						body: JSON.stringify(
							{
								usuario: usuario.value,
								email: email.value
							})
					}).then(() => {
					snackbarText.value = "Revisa tu correo electronico";
					snackbar.value = true;
					email.value = "";
					usuario.value = "";
				});
			} catch (e) { console.log("Error en la conexion"); router.push('/NetworkError'); }
		}
	}
</script>

<template>
	<div style="height: 100%; background-color: #AF091D;">
	<v-container>
	<v-row>
	  <v-col cols="12" sm="12" md="12">
		<v-card style="margin-top: 15px;">
		  <v-card-title align="center">
			<h3>Recuperar Contraseña</h3>
		  </v-card-title>
		  <v-card-text align="center">
			<v-form>
				<p>Introduce tu nombre de usuario y el email con el que te registraste. Si existen y coinciden, te enviaremos una nueva contraseña.</p>
				<v-text-field hide-details="auto" v-model="usuario" density="compact" placeholder="Nombre de usuario" style="margin-top: 10px; margin-bottom: 15px;" prepend-inner-icon="mdi-at" variant="outlined"></v-text-field>
				<v-text-field hide-details="auto" v-model="email" density="compact" placeholder="Email asociado" style="margin-bottom: 15px;" prepend-inner-icon="mdi-email-outline" variant="outlined"></v-text-field>
				<v-btn color="primary" @click="recuperarContrasena">Recuperar Contraseña</v-btn>
			</v-form>
		  </v-card-text>
		</v-card>
	  </v-col>
	</v-row>
  </v-container>
	</div>
	<!-- Mostrar mensaje satisfactorio -->
	<v-snackbar color="success" v-model="snackbar" :timeout="3000" style="margin-bottom: 100px; padding: 20px;" max-width="900px">
		<p style="font-size: 15px; padding: 0px;"> <v-icon icon="mdi-check-circle" style="margin-right: 8px;"></v-icon>{{ snackbarText }}</p>
	</v-snackbar>
	<!-- Mostrar mensaje de error en los campos -->
	<v-snackbar v-model="snackbar2" :timeout="3000" style="margin-bottom: 100px; padding: 20px;" max-width="900px">
		<p style="font-size: 15px; padding: 0px;"> <v-icon icon="mdi-alert-circle-outline" style="margin-right: 8px;"></v-icon>{{ snackbarText2 }}</p>
	</v-snackbar>

</template>

<style scoped>

</style>
