const express = require('express')
const routes = express.Router()

//Importar controladores donde están las funciones
const controllerLogin = require("../Controllers/controllerLogin")
const controllerRecaudacion = require("../Controllers/controllerRecaudacion")
const controllerRegalo = require("../Controllers/controllerRegalo")
const controllerPagos = require("../Controllers/controllerPagos")
const controllerValoracion = require("../Controllers/controllerValoracion")
const controllerAdmin = require('../Controllers/controllerAdmin')

//Endpoint Check
routes.get('/check', controllerAdmin.getCheck)

//Rutas relacionadas con Login, Logout, Registro y acceso del usuario
routes.post('/register', controllerLogin.postRegister)
routes.post('/login', controllerLogin.postLogin)
routes.get('/user', controllerLogin.getUser)
routes.post('/logout', controllerLogin.postLogout)
routes.post('/crearAdmin', controllerLogin.crearAdmin)
routes.post('/editarUsuario', controllerLogin.postEditarUsuario)
routes.post('/recuperarContrasena', controllerLogin.postRecuperarContrasena)
routes.post('/eliminarUsuario', controllerLogin.postEliminarUsuario)
//Rutas relacionadas con las recaudaciones
routes.post('/crearRecaudacion', controllerRecaudacion.postCrearRecaudacion)
routes.get('/recaudacion/:id', controllerRecaudacion.getRecaudacion)
routes.get('/recaudacionesAdmin', controllerRecaudacion.getRecaudacionesAdmin)
routes.get('/recaudacionesUser', controllerRecaudacion.getRecaudacionesUser)
routes.get('/recaudacionesPublicas', controllerRecaudacion.getRecaudacionesPublicas)
routes.get('/aportacionesUser', controllerRecaudacion.getAportacionesUser)
routes.post('/editarRecaudacion', controllerRecaudacion.postEditarRecaudacion)
routes.post('/aportacionesRecaudacion', controllerRecaudacion.getAportacionesRecaudacion)
routes.post('/aceptarPeticionRecadacion', controllerAdmin.postAceptarPeticionRecadacion)
routes.post('/denegarPeticionRecaudacion', controllerAdmin.postDenegarPeticionRecaudacion)
routes.post('/eliminarRecaudacion', controllerRecaudacion.postEliminarRecaudacion)
//Rutas relacionadas con los regalos
routes.post('/crearRegalo', controllerRegalo.postCrearRegalo)
//Rutas relacionadas con los pagos/Paypal
routes.post('/buy', controllerPagos.postBuy)
routes.get('/getSuccess', controllerPagos.getSuccess)
routes.get('/getErr', controllerPagos.getErr)
//Rutas relacionadas con las valoraciones
routes.post('/valoracion', controllerValoracion.postValoracion)
routes.get('/valoracionesAdmin', controllerValoracion.getValoraciones)
routes.get('/valoracion/:id', controllerValoracion.getValoracion)
routes.post('/borrarValoracion', controllerValoracion.postBorrarValoracion)

//Exportar
module.exports = routes;



















