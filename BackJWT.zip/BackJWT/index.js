const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const cookieParser = require('cookie-parser')
var paypal = require('paypal-rest-sdk');
const cron = require('node-cron'); 
const Recaudacion = require('./models/recaudacion');
const controllerRecaudacion = require('./Controllers/controllerRecaudacion')

//Conexion a la BBDD
mongoose.connect(`mongodb+srv://admin:iKJsCkCUt6eDsLf0@giftpool.ag0wj2s.mongodb.net/?retryWrites=true&w=majority&appName=Giftpool`).then(() => 
{
    console.log("Conexion con la BBDD correcta");
}).catch(err => {console.error("Connection error", err); process.exit(); });


//Coger las rutas creadas
const routes = require('./routes/routes')

app = express()
app.use(cookieParser())

const corsOptions = {
	origin: 'http://localhost:3000',
	credentials: true, 
	methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
	preflightContinue: false,
	optionsSuccessStatus: 204
};

app.use(cors(corsOptions));
app.options('*', cors())

app.use(express.json())           
app.use('/api', routes)

//Comprobar si alguna recaudacion ha llegado a su fecha de fin.
async function ComprobarFechaFinRecaudaciones()
{
	console.log('Comprobando fechas de fin de recaudaciones... -->', new Date());
	//Para cada recaudacion (no terminada, y aceptada), comprobar su fecha de fin
	const recaudaciones = await Recaudacion.find({ terminada: "false", estado: "aceptada"})
	let recaudacionesQueFinalizanHoy = [];

	recaudaciones.forEach(recaudacion =>
	{
		let fechaRecaudacion = new Date(recaudacion.fechaFin);
		let hoy = new Date();
		fechaRecaudacion.setHours(0, 0, 0, 0);
		hoy.setHours(0, 0, 0, 0);
		// Establecer las horas, minutos, segundos y milisegundos a 0 para comparar solo la fecha
		if (fechaRecaudacion.getTime() === hoy.getTime() || fechaRecaudacion.getTime() < hoy.getTime()) {
			recaudacionesQueFinalizanHoy.push(recaudacion);
			recaudacion.terminada = true;
			recaudacion.save().then(() => {
				controllerRecaudacion.cerrarRecaudacionFechaFin(recaudacion);
			});
		} 
	});
}

// Diariamente, a las 00:01, comprobar si alguna recaudacion ha llegado a su fecha de fin
cron.schedule('00 01 * * *', ComprobarFechaFinRecaudaciones);


app.listen(8000)


