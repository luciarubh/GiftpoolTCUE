//Modelo que va a seguir la entidad Aportacion
const mongoose = require('mongoose')

const aportacionSchema = new mongoose.Schema({
        //Usuario que ha hecho la aportacion
        userId:
        {
                type: String,
        },
        //
        username:
        {
                type: String,
        },
        //Recaudacion a la que ha aportado
        recaudacionId:
        {
                type: String,
        },
        //Fecha en la que se realiz� la aportaci�n
        fecha:
        {
                type: Date,
        },
        //Cantidad aportada a la recaudacion
        cantidadAportada:
        {
                type: Number,
        },
        regalo:
        {
                type: String,
        },
       
})

module.exports = mongoose.model('Aportacion', aportacionSchema)