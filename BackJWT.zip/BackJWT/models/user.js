//Modelo que va a seguir la entidad USER
const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
    nombreApellidos: 
    {
        type: String,
    },
    username: 
    {
        type: String,
    },
    email: 
    {
        type: String,
        unique: true,
    },
    password: 
    {
        type: String,
    }, 
    descripcion: 
    {
        type: String,
        required: false,
    },
    rol:
    {
        type: String,       
    },
    vquill:
    {
        type: String
    }
})

module.exports = mongoose.model('User', userSchema)