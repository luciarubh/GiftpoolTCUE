//Modelo que va a seguir la entidad Regalo
const mongoose = require('mongoose')

const regaloSchema = new mongoose.Schema({
    nombre:
    {
        type: String,
        required: true,
    },
    descripcion:
    {
        type: String,
    },
    cantidad:
    {
        type: Number,
        required: true
    },
    precioUnidad:
    {
        type: Number,
        required: true
    },
    precioTotal:
    {
        type: Number,
        required: true
    },
    //Enlace con la recaudaci�n
    recaudacion:
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Recaudacion'
    }
})

module.exports = mongoose.model('Regalo', regaloSchema)