//Modelo que va a seguir la entidad Recaudacion
const mongoose = require('mongoose')
const regalo = require('./regalo')

const recaudacionSchema = new mongoose.Schema({
        nombre:
        {
                type: String,
        },
        descripcion:
        {
                type: String,
        },
        fechaFin:
        {
                type: Date,
        },
        cantidadTotal:
        {
                type: Number,
        },
        cantidadActual:
        {
                type: Number,
        },
        userId:
        {
                type: String,
        },
        estado:
        {
                type: String,           //pendiente, aceptada, denegada
        },
        tipo:
        {
                type: Number,              //0 = Recaudacion, 1 = Aportacion
        },
        tipoRecaudacion:
        {
                type: Number,               //0 = Privada, 1 = Publica
        },
        imagen:
        {
                type: String,
        },
        vquill:
        {
                type: String,
        },
        motivo:
        {
                type: String,
        },
        terminada:
        {
                type: Boolean,
        }
})

module.exports = mongoose.model('Recaudacion', recaudacionSchema)