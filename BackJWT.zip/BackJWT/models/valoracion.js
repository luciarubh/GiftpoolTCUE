//Modelo que va a seguir la entidad Valoracion
const mongoose = require('mongoose')

const valoracionSchema = new mongoose.Schema({
        positivo:
        {
                type: String,
        },
        negativo:
        {
                type: String,
        },
        rating:
        {
                type: Number,
        },
        fecha:
        {
                type: Date,
        },
        //Usuario
        username:
        {
                type: String,
        },
        user:
        {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User'
        },
        vista:
        {
                type: Boolean,
        }
})

module.exports = mongoose.model('Valoracion', valoracionSchema)