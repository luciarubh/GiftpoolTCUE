const controllerLogin = require('../Controllers/controllerLogin')
const Recaudacion = require('../models/recaudacion')
const Aportacion = require('../models/aportacion')
const Regalo = require('../models/regalo')

var regalo = null;
var paypal = require('paypal-rest-sdk');
const controllerRecaudacion = require('../Controllers/controllerRecaudacion');
paypal.configure({
        'mode': 'sandbox',                                                                                      //Sandbox (Pruebas) o Live (Cuenta y dinero real)
        'client_id': 'AYhJ139MIvoIYDVqu7MFm8TmPGvTcV1AiBMNXknCizpc9KY2oA7bAi4mQf1OpUQhcV-os76kV7zJ5s1P',        //ClientID
        'client_secret': 'EDKH1K7D2blqE10EeomndE3n6HUGV1Yja9c5I9H8JUBeNIVsCbz7xeblXjU1MQjs1jRMotcfkXNhJjKt'     //Secret
});

/**
 * Realizar aportacion a un regalo.
 * @param {Regalo} regalo - Regalo que recibe la aportacion.
 * @param {User} user - Datos de ususario modificados.
 */
async function postBuy(req, res)
{
        try
        {
                regalo = req.body;
                //Comprobar si haciendo el pago se pasa de la cantidad  total
                if (regalo.cantidadActual + regalo.precioUnidad > regalo.cantidadTotal) {
                        res.status(500).json({ error: 'No se puede superar la cantidad total' });
                }
                else {
                        var payment =
                        {
                                "intent": "authorize",
                                "payer": { "payment_method": "paypal" },
                                "redirect_urls": {
                                        "return_url": "http://localhost:8000/api/getSuccess",                   //URL si el pago se realiza correctamente
                                        "cancel_url": "http://localhost:8000/api/getErr"                        //URL si el pago no se completa
                                },
                                "transactions": [{
                                        "amount": {
                                                "total": regalo.precioUnidad,
                                                "currency": "EUR"
                                        },
                                        "description": regalo.nombre,
                                }]
                        };

                        // Llamar al m�todo createPay
                        createPay(payment).then((transaction) =>
                        {
                                var id = transaction.id;
                                var links = transaction.links;
                                var redirectUrl = null;

                                for (var i = 0; i < links.length; i++) {
                                        if (links[i].method == 'REDIRECT') {
                                                redirectUrl = links[i].href;
                                                break;
                                        }
                                }
                                //Redirigir al cliente a la URL de pago de Paypal
                                if (redirectUrl) { res.json({ redirectUrl }); }
                                else { res.status(500).json({ error: 'No se ha encontrado la URL del pago' }); }

                        }).catch((err) => { res.status(500).json({ error: 'Error al crear el pago' }); });
                }
        } catch (error) { res.status(500).json({ error: 'Ha ocurrido alg�n error con el pago' });}
}



/**
 * Procesar pago correcto.
 * @param {Regalo} regalo - Datos del regalo que ha recibido la aportacion.
 */
async function getSuccess(req, res)
{
        console.log("Pago realizado correctamente.");
        //A�adir aportaci�n en la BD
        const User = await controllerLogin.obtenerIdUsuario(req)
        const aportacion = new Aportacion({
                userId: User._id,
                username: User.username,
                recaudacionId: regalo.recaudacion,
                fecha: Date.now(),
                cantidadAportada: regalo.precioUnidad,
                regalo: regalo.nombre
        });
        const recaudacion = await Recaudacion.findById(regalo.recaudacion)
        recaudacion.cantidadActual += regalo.precioUnidad
        const regaloBD = await Regalo.findOne({ nombre: regalo.nombre })
        if (regaloBD.cantidad > 0) { regaloBD.cantidad -= 1 }
        else regaloBD.cantidad = 0
        var result = await aportacion.save()
        var result = await recaudacion.save()
        var result = await regaloBD.save()
        if (recaudacion.cantidadTotal == recaudacion.cantidadActual || recaudacion.cantidadTotal < recaudacion.cantidadActual)
        {
                controllerRecaudacion.cerrarRecaudacion(recaudacion)
        }        
        //Redirigir al Front
        res.redirect('http://localhost:3000/pagoRealizado')
}

/** Procesar pago erroneo. */
async function getErr(req, res)
{
        console.log("�ERROR! Pago cancelado.");
        res.status(500).json({ error: 'Error: No se ha podido realizar el pago. Pruebe de nuevo' });
}

/** Crear pago dentro de la plataforma de PayPal. */
var createPay = (payment) => {
        return new Promise((resolve, reject) => {
                paypal.payment.create(payment, function (err, payment) {
                        if (err) { reject(err); }
                        else { resolve(payment); }
                });
        });
}	


//EXPORTAR ROUTER
module.exports = {
        postBuy: postBuy,
        getSuccess: getSuccess,
        getErr: getErr
}