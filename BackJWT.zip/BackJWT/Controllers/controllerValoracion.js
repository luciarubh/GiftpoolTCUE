const Valoracion = require('../models/valoracion')

/**
 * Registrar una valoracion en la base de datos.
 * @param {Valoracion} valoracion - Valoracion enviada por el usuario.
 */
async function postValoracion(req, res)
{
        try
        {
                const valoracion = new Valoracion({
                        user: req.body.valoracion.userId,
                        positivo: req.body.valoracion.positivo,
                        negativo: req.body.valoracion.negativo,
                        rating: req.body.valoracion.rating,
                        username: req.body.valoracion.username,
                        user: req.body.valoracion.userId,
                        fecha: req.body.valoracion.fecha,
                        vista: false,
                })
                await valoracion.save()
                res.status(201).json(valoracion)
        } catch (error) { console.log(error) }
}


/** Obtener el listado de valoraciones ordenadas por fecha, de m�s reciente a m�s antigua. */
async function getValoraciones(req, res)
{
        try
        {
                const listaValoraciones = await Valoracion.find().sort({ fecha: -1 });
                res.send({ message: listaValoraciones })
        } catch (error) { res.status(500).json({ error: 'Ha ocurrido un error al obtener las valoraciones.' }) }
}

/**
 * Obtener los datos de la valoracion recibida. 
 * @param {String} id - ID de la valoracion.
 */
async function getValoracion(req, res) {
        try
        {
                const valoracion = await Valoracion.findOne({ _id: req.params.id })
                return res.status(200).send({ "valoracion": valoracion })
        } catch (e) {return res.status(404).send({ message: 'Valoracion no encontrada' })}
}

/**
 * Marcar una valoracion como leida. 
 * @param {String} id - ID de la valoracion.
 */
async function postBorrarValoracion(req, res)
{
        try
        {
                const valoracion = await Valoracion.findOne({ _id: req.body._id })
                valoracion.vista = true
                valoracion.save()
                res.status(200).json({ message: 'Ok'})
        } catch (error) { res.status(500).json({ error: 'Ha ocurrido un error al borrar la valoracion.' }) }
        
}


//EXPORTAR ROUTER
module.exports = {
        postValoracion: postValoracion,
        getValoraciones: getValoraciones,
        getValoracion: getValoracion,
        postBorrarValoracion: postBorrarValoracion
}
