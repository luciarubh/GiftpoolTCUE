const router = require('express').Router()
const Regalo = require('../models/regalo')
const Recaudacion = require('../models/recaudacion')

/**
 * Crear un nuevo regalo asociado a la recaudacion especificada.
 * @param {Recaudacion} recaudacion - Recaudacion asociada.
 * @param {String} nombre - Nombre del regalo.
 * @param {String} descripcion - Descripcion.
 * @param {String} cantidad - Numero de unidades.
 * @param {String} precioUnidad - Precio por unidad.
 * @param {String} precioTotal - Precio total de todas las unidades.
 */
async function postCrearRegalo(req, res)
{
    const recaudacion = await Recaudacion.findOne({ nombre: req.body.recaudacion })

    const regalo = new Regalo({
        nombre: req.body.nombre,
        descripcion: req.body.descripcion,
        cantidad: req.body.cantidad,
        precioUnidad: req.body.precioUnidad,
        precioTotal: req.body.precioTotal,
        recaudacion: recaudacion._id
    })

    const result = await regalo.save()
    const resultado = await result.toJSON()
    res.send(resultado)  
}



//EXPORTAR ROUTER
module.exports = {
    postCrearRegalo: postCrearRegalo
}




