const router = require('express').Router()
const bcrypt = require('bcryptjs')      //Para encriptar la contrase�a
const jwt = require('jsonwebtoken')
const User = require('../models/user') //Importar modelo User
const dotenv = require('dotenv')
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const Recaudacion = require('../models/recaudacion')
const Regalo = require('../models/regalo')

let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
                type: 'OAuth2',
                user: "giftpoolinfo@gmail.com",
                pass: "GP_tfg&10",
                clientId: "753293901216-up0nn2pspnbihpam4t1o7711e40mrjbq.apps.googleusercontent.com",
                clientSecret: "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",
                refreshToken: "1//04pew25yKUa0PCgYIARAAGAQSNwF-L9IrhS7vuScfULJ_RcBCWCulgkuzVtX_oVFI9Slie9cv7nwR7uIJKcC-RM0Sc-g21BCg9kw"
        }
});

/**
 * Crear usuario en el sistema, comprobando la exitencia previa del nombre de usuario o email.
 * @param {String} username - Nombre de registro.
 * @param {String} email - Email de registro.
 * @param {String} nombreApellidos - Nombre y apellidos de registro.
 * @param {String} password - Contrae�a de usuario.
 * @param {String} descripcion - Descripcion del usuario.
 */
async function postRegister(req, res)
{
        //Comprobar que el nombre de usuario y el email no est�n ya en uso
        const user = await User.findOne({
                $or: [
                        { username: req.body.username },
                        { email: req.body.email }
                ]
        });
        if (user)
        {
                res.status(403).send({ message: "El nombre de usuario o email ya est� en uso" })
        }
        else
        {
                try {
                        //Encriptar la contrase�a con salt+hash
                        const salt = await bcrypt.genSalt(10)
                        const hashedPassword = await bcrypt.hash(req.body.password, salt)

                        const user = new User({
                                nombreApellidos: req.body.nombreApellidos,
                                username: req.body.username,
                                email: req.body.email,
                                password: hashedPassword,
                                descripcion: req.body.descripcion
                        })

                        const result = await user.save()                        //Guardar usuario en la BD
                        const { password, ...data } = await result.toJSON()     //Separa la contrase�a del resto de los datos
                        res.send(data)                                          //Enviar el resto de datos (sin la contrase�a)
                } catch (error) { res.status(400).send({ message: error }) }
        }
    

}

/**
 * Iniciar sesi�n en el sistema con una cuenta de usuario.
 * @param {String} email - Email de inicio de sesion.
 * @param {String} email - Contrase�a de usuario.
 */
async function postLogin(req, res)
{
    const user = await User.findOne({ username: req.body.email })
    //Ver si existe el usuario en la BD
    if (!user) 
    {
        return res.status(404).send({ message: 'Usuario no encontrado' })
    }
    //Comparar contrase�a de la req con la BD
    if (!await bcrypt.compare(req.body.password, user.password)) 
    {
        return res.status(400).send({ message: 'Contrase�a incorrecta' })
    }
    //crear token
    const token = jwt.sign({ _id: user._id }, "secret")
    res.cookie('jwt', token,
    {
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, //aprox 1 dia (est� en ms)
    })
    //Devolver usuario
    res.status(200).send({ message: user })
}

/**
 * Obtener datos del usuario que ha enviado la peticion.
 * @param {Cookie} JWT - Token de autenticacion de usuario.
 */
async function getUser(req, res)
{
        try
        {
        const cookie = req.cookies['jwt']
        const claims = jwt.verify(cookie, 'secret')
        //Error en la verificacion (cookie incorrecta)
                if (!claims) { return res.status(401).send({ message: 'Unauthenticated' }) }
        const user = await User.findOne({ _id: claims._id })
        const { password, ...data } = await user.toJSON()

        if (data.username === "admin") 
        { 
                res.status(202).send(data)
        }
        else
        {
                res.send(data)
        }        

    } catch (e) {
                //Error en la verificacion (no hay cookie)
        return res.status(401).send({ message: 'Unauthenticated' })
    }
}

/**
 * Obtener identificador del usuario que ha enviado la peticion.
 * @param {Cookie} JWT - Token de autenticacion de usuario.
 */
async function obtenerIdUsuario(req)
{
        try {
                const cookie = req.cookies['jwt']
                const claims = jwt.verify(cookie, 'secret')

                //Error en la verificacion (cookie incorrecta)
                if (!claims) {return res.status(401).send({ message: 'Unauthenticated' })}
                const user = await User.findOne({ _id: claims._id });
                return user
        } catch (e) {
                //Error en la verificacion (no hay cookie)
                console.log(e.message)
                return "Unauthenticated"
        }
}

/**
 * Cerrar sesi�n del usuario que ha enviado la peticion.
 * @param {Cookie} JWT - Token de autenticacion de usuario.
 */
async function postLogout(req, res)
{
    //Eliminar cookie (hacer que expire inmediatamente)
    res.cookie('jwt', '', { maxAge: 0 })
    res.send({ message: 'Successing Logout' })
    console.log("Logout correcto");
}

/**
 * Eliminar usuario que ha enviado la peticion.
 * @param {User} user - Usuario que ha enviado la peticion.
 */
async function postEliminarUsuario(req, res)
{
        //Comprobar si tiene recaudaciones activas
        const recaudacionesNoTerminadas = await Recaudacion.find({
                userId: req.body.user._id,
                terminada: false
        });

        if (recaudacionesNoTerminadas.length > 0)
        {
                return res.status(406).send({ message: 'Usuario no eliminado' })
        }
        else
        {
                eliminarDatosUsuario(req.body.user)
                //Eliminar usuario
                await User.deleteOne({ _id: req.body.user._id });
                res.cookie('jwt', '', { maxAge: 0 })
                res.send({ message: 'Usuario eliminado' })
        }
}

/**
 * Eliminar datos del usuario que ha enviado la peticion.
 * @param {User} user - Usuario que ha enviado la peticion.
 */
async function eliminarDatosUsuario(usuario)
{
        const regalos = []

        //Obtener las recaudaciones y regalos
        const recaudaciones = await Recaudacion.find({ userId: usuario._id });

        for (let recaudacion of recaudaciones)
        {
                let regalosDeRecaudacion = await Regalo.find({ recaudacion: recaudacion._id });
                for (let regalo of regalosDeRecaudacion) {
                        regalos.push(regalo);
                }
        }
        //Eliminar regalos
        for (let regalo of regalos)
        {
                await Regalo.deleteOne({ _id: regalo._id });
        }

        //Eliminar recaudaciones
        for (let recaudacion of recaudaciones)
        {
                await Recaudacion.deleteOne({ _id: recaudacion._id });
        }

        
}

/** Funci�n inicial para crear el perfil del administrador. */
async function crearAdmin(req, res)
{
    const cookie = req.cookies['jwt']
    const claims = jwt.verify(cookie, 'secret')
    //Error en la verificacion (cookie incorrecta)
    if (!claims) {
        return res.status(401).send({ message: 'Unauthenticated' })
    }
    //Encriptar la contrase�a con salt+hash
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(req.body.password, salt)

    const user = new User({
        nombreApellidos: req.body.nombreApellidos,
        username: req.body.username,
        email: req.body.email,
        password: hashedPassword,
        descripcion: req.body.descripcion
    })

    const result = await user.save()                    //Guardar usuario en la BD
    const { password, ...data } = await result.toJSON()   //Separa la contrase�a del resto de los datos
    res.send(data)                                      //Enviar el resto de datos (sin la contrase�a)

}

/**
 * Editar datos del usuario que ha enviado la peticion.
 * @param {Cookie} JWT - Token de autenticacion de usuario.
 * @param {User} user - Datos de ususario modificados.
 */
async function postEditarUsuario(req, res)
{
        const cookie = req.cookies['jwt']
        const claims = jwt.verify(cookie, 'secret')
        //Error en la verificacion (cookie incorrecta)
        if (!claims) {
                return res.status(401).send({ message: 'Unauthenticated' })
        }
        const user = await User.findOne({ _id: claims._id })
        //Encriptar la contrase�a
        if (req.body.user.password !== "")
        {
                const salt = await bcrypt.genSalt(10)
                const hashedPassword = await bcrypt.hash(req.body.user.password, salt)
                user.password = hashedPassword;
        }
        
        user.nombreApellidos = req.body.user.nombreApellidos
        user.username = req.body.user.username
        user.email = req.body.user.email
        user.vquill = req.body.user.vquill
        await user.save();
        res.send()
}

/**
 * Crear nueva contrase�a de usuario, comprobando si los campos son correctos.
 * @param {String} email - Email del perfil.
 * @param {String} usuario - Usuario del perfil.
 */
async function postRecuperarContrasena(req, res)
{
        const destinatario = req.body.email;
        const usuario = req.body.usuario;

        //Comprobar si el usuario existe y los datos coinciden
        const user = await User.findOne({ username: usuario, email: destinatario });
        //SI LOS DATOS SON CORRECTOS
        if (user)
        {
                //Generar nueva contrase�a
                let nuevaContrasena = ""
                const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
                const length = 8;
                while (nuevaContrasena.length < length) {
                        const byte = crypto.randomBytes(1)[0];
                        if (charset[byte % charset.length]) {
                                nuevaContrasena += charset[byte % charset.length];
                        }
                }

                //Encriptar la nueva contrase�a
                const salt = await bcrypt.genSalt(10)
                const hashedPassword = await bcrypt.hash(nuevaContrasena, salt)
                user.password = hashedPassword;
                await user.save();

                //Datos del correo a enviar
                const mensaje = "Hola " + usuario + ",\nHemos recibido una peticion de recuperacion de contrasena para tu cuenta de Giftpool." +
                        "\nTu nueva contrasena para poder acceder a Giftpool es: " + nuevaContrasena +
                        "\nUna vez inicies sesion, te recomendamos establecer una nueva contrasena." +
                        "\n\nUn saludo,\nEl equipo de Giftpool.";
                let mailOptions =
                {
                        from: "giftpoolinfo@gmail.com",
                        to: destinatario,
                        subject: 'Recuperar contrasena',
                        text: mensaje
                };

                //Enviar el correo
                transporter.sendMail(mailOptions, function (err, data)
                {
                        if (err) { console.log("Error al enviar el correo de recuperacion:" + err); }
                        else { console.log("Email de recuperacion enviado correctamente"); }
                });
        } else
        {
                console.log("Usuario no encontrado")
        }       
        res.send("")
}




//EXPORTAR ROUTER
module.exports = {
    postRegister: postRegister,
    postLogin: postLogin,
    getUser: getUser,
    postLogout: postLogout,
    crearAdmin: crearAdmin,
    obtenerIdUsuario: obtenerIdUsuario,
    postEditarUsuario: postEditarUsuario,
    postRecuperarContrasena: postRecuperarContrasena,
    postEliminarUsuario: postEliminarUsuario
}








