const router = require('express').Router()
const Recaudacion = require('../models/recaudacion') 
const Regalo = require('../models/regalo') 
const Aportacion = require('../models/aportacion')
const controllerLogin = require('../Controllers/controllerLogin')

/**
 * Obtener los datos de la recaudacion recibida. 
 * @param {String} id - ID de la recaudacion.
 */
async function getRecaudacion(req, res)
{
	try
	{
		const recaudacion = await Recaudacion.findOne({ _id: req.params.id })
		const regalos = await Regalo.find({ recaudacion: req.params.id })
		return res.status(200).send({ "recaudacion": recaudacion, "regalos": regalos })
	} catch (e) { return res.status(404).send({ message: 'No encontrada' }) }
}

/**
 * Crear recaudacion y regalos asociados en la base de datos. 
 * @param {Recaudacion} recaudacion - Datos de la recaudacion.
 * @param {Regalo[]} regalos - Datos de los regalos asociados.
 */
async function postCrearRecaudacion(req, res)
{
	let tipoRecaudacion = 0;
	const User = await controllerLogin.obtenerIdUsuario(req)
	if (req.body.recaudacion.tipo === "Publica (Todo el mundo)") tipoRecaudacion = 1;

	const recaudacion = new Recaudacion({
		userId: User.id, 
		nombre: req.body.recaudacion.nombre,
		descripcion: req.body.recaudacion.descripcion,
		fechaFin: req.body.recaudacion.fechaFin,
		imagen: req.body.recaudacion.foto,
		cantidadTotal: req.body.recaudacion.total,
		cantidadActual: 0,
		vquill: req.body.recaudacion.vquill,
		tipo: 0,
		tipoRecaudacion: tipoRecaudacion,
		estado: "pendiente",
		terminada: false
	})

	var result = await recaudacion.save()
	req.body.recaudacion.regalos.forEach(function (reg)
	{
		const regalo = new Regalo
		({
			nombre: reg.nombre,
			cantidad: reg.cantidad,
			precioUnidad: reg.precioUnidad,
			precioTotal: reg.precioUnidad * reg.cantidad,
			recaudacion: result._id
		})
		regalo.save()
	});	
}


/**
 * Modificar recaudacion recibida. 
 * @param {Recaudacion} recaudacion - Datos existentes de la recaudacion.
 * @param {Regalo[]} regalos - Datos de los regalos existentes.
 */
async function postEditarRecaudacion(req, res)
{
	//Actualizar recuadacion
	const recaudacion = await Recaudacion.findOne({ _id: req.body.recaudacion._id })
	recaudacion.nombre = req.body.recaudacion.nombre;
	recaudacion.descripcion = req.body.recaudacion.descripcion;
	recaudacion.fechaFin = req.body.recaudacion.fechaFin;
	recaudacion.cantidadTotal = req.body.recaudacion.cantidadTotal;
	if (req.body.recaudacion.tipoRecaudacion == "Publica (Todo el mundo)") recaudacion.tipoRecaudacion = 1;
	else recaudacion.tipoRecaudacion = 0;
	recaudacion.imagen = req.body.recaudacion.imagen;
	recaudacion.vquill = req.body.recaudacion.vquill;
	//En el caso de que sea una recaudacion denegada y se quiera volver a revisar
	if(req.body.recaudacion.estado == "denegada") recaudacion.estado = "pendiente";

	await recaudacion.save();
	//Cargar los regalos de la recaudacion actuales de la BD
	const regalosDB = await Regalo.find({ recaudacion: recaudacion._id });
	for (let regaloDB of regalosDB)
	{
		//Coprobar si el regalo est� en la nueva lista de regalos
		const regaloEnReq = req.body.regalos.find(regalo => regalo._id === regaloDB._id.toString());
		// Si el regalo de la base de datos no est� en el array de regalos, se elimina de la BD
		if (!regaloEnReq) {
			await Regalo.deleteOne({_id: regaloDB._id});
		}
	}
	//Actualizar regalos existentes
	req.body.regalos.forEach(async function (reg) {
                const regalo = await Regalo.findOne({ _id: reg._id })
                regalo.nombre = reg.nombre;
                regalo.cantidad = reg.cantidad;
                regalo.precioUnidad = reg.precioUnidad;
                regalo.precioTotal = reg.precioUnidad * reg.cantidad;
                await regalo.save();
        })
}


/**
 * Obtener las recaudaciones del administrador (pendientes, confirmadas y denegadas). 
 * @param {User} usuario - Usuario que envia la peticion.
 */
async function getRecaudacionesAdmin(req, res)
{
	const user = await controllerLogin.obtenerIdUsuario(req)
	if (user.username != "admin") {
		return res.send({ message: 'No eres admin' })
	}
	const listaPendientes = await Recaudacion.find({ estado: 'pendiente' }).exec();
	const listaAceptadas = await Recaudacion.find({ estado: 'aceptada' }).exec();
	const listaDenegadas = await Recaudacion.find({ estado: 'denegada' }).exec();
	res.send({
		listaPendientes: listaPendientes,
		listaAceptadas: listaAceptadas,
		listaDenegadas: listaDenegadas
	});
}


/**
 * Obtener las recaudaciones publicadas por el usuario que env�a la petici�n.
 * @param {User} usuario - Usuario que envia la peticion.
 */
async function getRecaudacionesUser(req, res)
{
	const User = await controllerLogin.obtenerIdUsuario(req)
	const listaRecaudaciones = await Recaudacion.find({ userId: User._id }).exec();
	res.send({ message: listaRecaudaciones})
}

/**
 * Obtener las aportaciones realizadas por el usuario que env�a la petici�n.
 * @param {User} usuario - Usuario que envia la peticion.
 */
async function getAportacionesUser(req, res) {
	const User = await controllerLogin.obtenerIdUsuario(req)
	const listaAportaciones = await Aportacion.find({ userId: User._id }).sort({ fecha: -1 }).exec();
	res.send({ message: listaAportaciones })
}

/** Obtener listado de recaudaciones publicas del sistema. */
async function getRecaudacionesPublicas(req, res)
{
	const recaudacionesPublicas = await Recaudacion.find({ tipoRecaudacion: 1, terminada: false }).exec();
	res.send({ message: recaudacionesPublicas })
}


/**
 * Obtener las aportaciones recibidas en una recaudacion.
 * @param {String} id - Identificador de la recaudacion.
 */
async function getAportacionesRecaudacion(req, res)
{
	const aportaciones = await Aportacion.find({ recaudacionId: req.body.id }).sort({ fecha: -1 }).exec();
	res.send({ message: aportaciones })
}

/**
 * Cerrar recaudacion cuando se ha llegado a la cantidad establecida.
 * @param {Recaudacion} recaudacion - Recaudacion a cerrar.
 */
async function cerrarRecaudacion(recaudacion)
{
	recaudacion.terminada = true
	await recaudacion.save()
	//Enviar todo el dinero recaudado al recaudador
}

/**
 * Cerrar recaudacion cuandose ha llegado a la fecha de fin.
 * @param {Recaudacion} recaudacion - Recaudacion a cerrar.
 */
async function cerrarRecaudacionFechaFin(recaudacion)
{
	recaudacion.terminada = true
	await recaudacion.save()
	//Devolver el dinero a los aportantes
	console.log(recaudacion)
	let DevolucionesARealizar = await Aportacion.find({ recaudacionId: recaudacion._id }).exec();
	console.log("Se tienen que realizar las siguientes devoluciones:")
	console.log(DevolucionesARealizar)
}

/**
 * Eliminar recaudacion de la base de datos.
 * @param {Recaudacion} recaudacion - Recaudacion a cerrar.
 */
async function postEliminarRecaudacion(req, res)
{
	const recaudacion = await Recaudacion.findOne({ _id: req.body.recaudacion._id });
	//Si est� terminada
	if (recaudacion.terminada == true)
	{
		let regalosDeRecaudacion = await Regalo.find({ recaudacion: recaudacion._id });
		for (let regalo of regalosDeRecaudacion) {
			await Regalo.deleteOne({ _id: regalo._id });
		}
		await Recaudacion.deleteOne({ _id: recaudacion._id });
		return res.status(200).send({ message: 'Recaudacion eliminada' })
	}
	else
	{
		return res.status(406).send({ message: 'Recaudacion no eliminada' })
	}
}

//EXPORTAR ROUTER
module.exports = {
    postCrearRecaudacion: postCrearRecaudacion,
    getRecaudacion: getRecaudacion,
    getRecaudacionesAdmin: getRecaudacionesAdmin,
    getRecaudacionesUser: getRecaudacionesUser,
    getRecaudacionesPublicas: getRecaudacionesPublicas,
    getAportacionesUser: getAportacionesUser,
    postEditarRecaudacion: postEditarRecaudacion,
    getAportacionesRecaudacion: getAportacionesRecaudacion,
    cerrarRecaudacion: cerrarRecaudacion,
    cerrarRecaudacionFechaFin: cerrarRecaudacionFechaFin,
    postEliminarRecaudacion: postEliminarRecaudacion
}




