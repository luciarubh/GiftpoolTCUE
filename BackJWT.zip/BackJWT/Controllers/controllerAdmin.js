const router = require('express').Router()
const Recaudacion = require('../models/recaudacion')
const Regalo = require('../models/regalo')
const Aportacion = require('../models/aportacion')
const controllerLogin = require('../Controllers/controllerLogin')


/**
 * Publicar recaudacion pendiente en la plataforma.
 * @param {Recaudacion} recaudacion - Recaudacion a publicar.
 */
async function postAceptarPeticionRecadacion(req, res)
{
        const recaudacion = await Recaudacion.findOne({ _id: req.body.id })
        recaudacion.estado = "aceptada"
        recaudacion.save()
}

/**
 * Establecer recaudacion como denegada, con su motivo correspondiente.
 * @param {Recaudacion} recaudacion - Recaudacion a publicar.
 * @param {String} motivo- Motivo por el cual se ha denegado la recaudacion.
 */
async function postDenegarPeticionRecaudacion(req, res)
{
        const recaudacion = await Recaudacion.findOne({ _id: req.body.id })
        recaudacion.estado = "denegada"
        recaudacion.motivo = req.body.motivo
        recaudacion.save()
}

/** Comprobar el funcionamiento correcto del sistema.
 */
async function getCheck(req, res)
{
        return res.status(200).send({ message: 'Servidor funcionando' })
}


//EXPORTAR ROUTER
module.exports = {
        postAceptarPeticionRecadacion: postAceptarPeticionRecadacion,
        postDenegarPeticionRecaudacion: postDenegarPeticionRecaudacion,
        getCheck: getCheck
}